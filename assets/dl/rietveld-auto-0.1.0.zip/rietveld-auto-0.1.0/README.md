# rietveld-auto

AI가 지휘하는 분말 X선 리트벨트 정련 엔진. Buzz 채널 `Rietveld Auto project` 작업물.

```bash
pip install -r requirements.txt
python -m rietveld.cli serve --data data/demo_VO2_M1.xy   # → http://127.0.0.1:8765
```

**AI 에이전트가 이 도구를 쓰는 법은 [`SKILL.md`](SKILL.md) 에 있다.** 모든 명령이
JSON 을 돌려주므로 Claude Code · Codex 등 어떤 에이전트든 같은 결론을 재현·검증할 수 있다.

```bash
python -m rietveld.cli search  --formula VO2
python -m rietveld.cli index   --data pattern.asc          # CIF 없이 자동 지수화
python -m rietveld.cli analyze --data pattern.asc --cod 7231905 \
        --asymmetry --impurity "PbCl2,CsCl,Pb" --lebail-pnma 5.684
```

## 설계 원칙

**엔진은 결정론적이고, AI는 그 위에 있다.** AI는 진단 JSON을 읽고 `plan` JSON을
만들 뿐이며, 실행은 `refine()`이 한다. 모든 단계는 스냅샷으로 남아 되돌릴 수 있고,
AI 없이 같은 plan을 넣으면 같은 답이 나온다.

```
CIF(COD) ─┐
          ├─► RefinementState ──► refine(plan) ──► {R, params, esd, corr, checks}
패턴 파일 ─┘          ▲                                      │
                     └──────── AI (채팅) ◄───── 진단 JSON ────┘
```

## 검증 (2026-09-30)

합성 참값 재현 시험. COD 3000344 (VO₂ M1) 로 Cu Kα1+Kα2 패턴을 만들고
(zero 0.028°, 시료변위 −0.010, U 0.016 / V −0.006 / W 0.0085, η₀ 0.58,
March-Dollase(011) 1.15, Chebyshev 배경, Poisson 잡음, 15–80° 0.02° 3250점),
COD 검색부터 정련까지 전 과정을 돌렸다.

| 항목 | 정련값 | 참값 | 비고 |
|---|---|---|---|
| Rwp / Rp / **GOF** | 8.139 / 5.259 / **1.010** | Rexp 8.061 | 잡음 한계 도달 |
| a (Å) | 5.75248 | 5.75232 | +0.003 % |
| b (Å) | 4.52548 | 4.52539 | +0.002 % |
| c (Å) | 5.38242 | 5.38237 | +0.001 % |
| β (°) | 122.6118 | 122.6112 | +0.0006° |
| March-Dollase r | 1.1492 | 1.1500 | −0.07 % |
| zero (°2θ) | 0.0179 | 0.028 (+ 변위 −0.010) | **변위를 흡수 — 설계대로** |
| U / V / W | 0.0118 / −0.0028 / 0.0078 | 0.016 / −0.006 / 0.0085 | U–V 상관 −0.99, 경고 발생 |

COD 후보 순위도 함께 검증했다. `VO2` 로 검색하면 60건 중 조성비가 실제로 맞는 것은
11건이고(V₅O₉ 등이 걸러진다), 관측 피크 위치와 비교한 순위 1위는 정답인 COD 3000344
(일치율 100 %, 평균 편차 0.042°)였다. 2위는 B상 C2/m (84.6 %), 3·4위는 루타일 R상
P4₂/mnm (65 %, 62 %).

**여기서 배운 것:** 같은 데이터에서 Rwp 12.9와 8.1(GOF 1.01)을 가른 것은 최적화
알고리즘이 아니라 ① 우선방위 축을 (001) 기본값이 아니라 (011)로 고른 것, ② 영점과
시료변위를 동시에 풀지 않은 것 — 둘 다 **모델 선택** 판단이다. AI가 있어야 할 자리가
바로 여기다.

## 물리적 타당성 층 (`rietveld/physics.py`)

FullProf는 정련이 물리적으로 말이 안 되는 곳으로 가도 막지 않는다. 여기서는 두 층으로 막는다.

**HARD — 즉시 거부하고 직전 스냅샷으로 롤백**

- NaN/Inf, 단위포 부피 ≤ 0, 성립하지 않는 격자 계량(코사인 행렬식 ≤ 0)
- 측정 범위 안 어디서든 Caglioti FWHM² ≤ 0 (음의 피크 폭)
- 상 스케일 ≤ 0, pseudo-Voigt η ∉ [0,1], March-Dollase r ≤ 0
- 점유율 ∉ (0,1], B_iso < 0
- 결정계가 허용하지 않는 격자 자유도는 **애초에 만들지 않는다**
  (`Phase.free_cell_params()` — 정방정에서 a·c만, 입방정에서 a만 노출)
- Rwp가 나빠지면 그 단계는 되돌린다 (`allow_worse=True` 로 명시적 해제 가능)

**WARN — 막지 않고 AI·사용자에게 올린다** (물질 보편의 임의 컷오프를 강제하지 않는다)

- 참조 CIF 격자 대비 이탈(기본 2 %) — 영점·시료변위와 얽힐 수 있음을 함께 표시
- 공유결합 반지름 합의 75 % 미만인 최단 접촉거리
- 파라미터 상관 |ρ| > 0.95
- B_iso > 8 Å²
- **Rwp는 좋아졌는데 차이 곡선 최대 잔차는 커진 경우**

## FullProf 대비 구현 현황

전체 동등성을 주장하지 않는다. 현재 상태는 이렇다.

| 기능 | 상태 |
|---|---|
| CIF 읽기 (COD/로컬), 공간군 대칭, 소광조건, 다중도 | ✅ |
| 원자산란인자 (IT92), Debye-Waller, 구조인자 | ✅ |
| Cu/Co/Mo/Cr/Fe Kα1 단독 ↔ Kα1+Kα2 토글 | ✅ |
| pseudo-Voigt + Caglioti U,V,W, η = η₀ + η₁·2θ | ✅ |
| Chebyshev 배경 (차수 가변) | ✅ |
| 영점 · 시료 변위 · 투과 보정 | ✅ |
| March-Dollase 우선방위 | ✅ |
| 격자상수 · 원자좌표 · 점유율 · B_iso 정련 | ✅ |
| 공분산에서 esd, 상관행렬 | ✅ |
| 다상 동시 정련 · Hill-Howard 중량분율 | ⚠️ 코드 경로는 있으나 다상 실측 검증 안 함 |
| CIF / `.prf` / JSON 내보내기 | ✅ (FullProf `.out` 대응은 JSON) |
| Thompson-Cox-Hastings 프로파일 (크기/변형 분리) | ✅ `--tch` |
| Bérar-Baldinozzi 비대칭 (FullProf Asy1..4) | ✅ `--asymmetry` |
| Le Bail 강도 추출 (구조 미상 상) | ✅ `--lebail-pnma` |
| 자동 지수화 + 기하 모델 선택 | ✅ `cli index` |
| 배제 추론 진단 (`rietveld/diagnose.py`) | ✅ `cli analyze` |
| `.xy` `.dat` `.xrdml` 읽기 | ✅ (`.raw` 미지원) |
| 축발산 비대칭의 엄밀형(Finger-Cox-Jephcoat) | ❌ (Bérar-Baldinozzi 근사로 대체) |
| 이방성 변형(Stephens) | ❌ |
| 흡수·투과 보정(두께 의존), 표면 거칠기 | ❌ |
| 소광, 강체(rigid body), 거리·각도 구속 | ❌ |
| 중성자 (상수파장/TOF), 자기구조 | ❌ |
| 단결정, 박막 GIXRD 기하 | ❌ |

## AI 채팅

`RIETVELD_AI` 환경변수로 백엔드를 고른다: `claude`(기본) · `codex` · `rule`(오프라인).
AI는 `rietveld/session.py`의 `SYSTEM` 프롬프트를 따르며, 정련을 제안할 때만
` ```plan ` 블록으로 실행 가능한 단계를 낸다. 사용자가 버튼을 눌러야 실행된다.

## 파일

```
rietveld/structure.py  CIF → Phase, 반사 생성, |F|²
rietveld/pattern.py    파장·프로파일·배경·패턴 계산
rietveld/physics.py    물리적 타당성 검사 (HARD / WARN)
rietveld/refine.py     파라미터 레지스트리, 최소제곱, 스냅샷/롤백, esd
rietveld/cod.py        COD 검색·CIF 내려받기·후보 순위
rietveld/session.py    세션·이벤트 버스·AI 어드바이저
rietveld/diagnose.py   진단 스킬 (배제 추론) — 전부 JSON 반환
rietveld/cli.py        AI 에이전트용 CLI (search / index / analyze / serve)
rietveld/server.py     HTTP + SSE 서버, 내보내기
web/index.html         실시간 화면 + 채팅 (의존성 없음)
```
