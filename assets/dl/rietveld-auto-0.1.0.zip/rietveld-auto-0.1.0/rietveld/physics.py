"""물리적 타당성 검사층.

FullProf는 정련이 물리적으로 말이 안 되는 곳으로 가도 막지 않는다.
여기서는 두 층으로 막는다.

1. HARD  — 기계적으로 판정 가능한 위반. 즉시 거부하고 직전 스냅샷으로 롤백한다.
2. WARN  — 물질마다 다를 수 있는 신호. 막지 않고 AI/사용자에게 올린다.

물질 보편의 임의 컷오프를 HARD로 넣지 않는다. 격자상수는 영점·시료변위와,
점유율은 스케일·온도인자와 얽히므로 '값이 크다'는 것만으로 거부하지 않는다.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

# 원소별 공유결합 반지름 (A). 결합거리 하한 경고에만 쓴다.
_COV = {
    "H": 0.31, "Li": 1.28, "Be": 0.96, "B": 0.84, "C": 0.76, "N": 0.71,
    "O": 0.66, "F": 0.57, "Na": 1.66, "Mg": 1.41, "Al": 1.21, "Si": 1.11,
    "P": 1.07, "S": 1.05, "Cl": 1.02, "K": 2.03, "Ca": 1.76, "Sc": 1.70,
    "Ti": 1.60, "V": 1.53, "Cr": 1.39, "Mn": 1.39, "Fe": 1.32, "Co": 1.26,
    "Ni": 1.24, "Cu": 1.32, "Zn": 1.22, "Ga": 1.22, "Ge": 1.20, "As": 1.19,
    "Se": 1.20, "Br": 1.20, "Rb": 2.20, "Sr": 1.95, "Y": 1.90, "Zr": 1.75,
    "Nb": 1.64, "Mo": 1.54, "Ru": 1.46, "Rh": 1.42, "Pd": 1.39, "Ag": 1.45,
    "Cd": 1.44, "In": 1.42, "Sn": 1.39, "Sb": 1.39, "Te": 1.38, "I": 1.39,
    "Cs": 2.44, "Ba": 2.15, "La": 2.07, "Ce": 2.04, "Hf": 1.75, "Ta": 1.70,
    "W": 1.62, "Re": 1.51, "Os": 1.44, "Ir": 1.41, "Pt": 1.36, "Au": 1.36,
    "Hg": 1.32, "Pb": 1.46, "Bi": 1.48,
}


@dataclass
class Check:
    level: str        # 'hard' | 'warn'
    code: str
    message: str
    value: float | None = None

    def as_dict(self):
        return {"level": self.level, "code": self.code,
                "message": self.message, "value": self.value}


def _cell_is_valid(ph) -> bool:
    a, b, c, al, be, ga = ph.cell_params
    if min(a, b, c) <= 0 or not all(0 < x < 180 for x in (al, be, ga)):
        return False
    ca, cb, cg = (math.cos(math.radians(x)) for x in (al, be, ga))
    # 격자 계량 행렬식 > 0 이어야 실제 격자가 성립한다
    det = 1 - ca * ca - cb * cb - cg * cg + 2 * ca * cb * cg
    return det > 1e-9


def min_bond_lengths(ph, max_r: float = 3.2):
    """비대칭 단위 원자 각각의 최단 접촉거리 (주변 1셀 이미지 포함)."""
    from .structure import expand_sites
    cell = ph.cell()
    exp = expand_sites(ph)
    allpos, allel = [], []
    for site, pos in exp:
        for p in pos:
            allpos.append(p)
            allel.append(site.element)
    allpos = np.array(allpos)
    out = []
    shifts = np.array([[i, j, k] for i in (-1, 0, 1)
                       for j in (-1, 0, 1) for k in (-1, 0, 1)])
    for site, pos in exp:
        p0 = pos[0]
        best, partner = float("inf"), None
        for q, el in zip(allpos, allel):
            for s in shifts:
                dfr = q + s - p0
                if not dfr.any():
                    continue
                v = cell.orthogonalize(type("F", (), {})()) if False else None
                dx = _ortho(cell, dfr)
                r = float(np.linalg.norm(dx))
                if 1e-3 < r < best:
                    best, partner = r, el
        if partner is not None and best < max_r:
            out.append((site, partner, best))
    return out


def _ortho(cell, frac):
    a, b, c = cell.a, cell.b, cell.c
    al, be, ga = (math.radians(x) for x in (cell.alpha, cell.beta, cell.gamma))
    ca, cb, cg, sg = math.cos(al), math.cos(be), math.cos(ga), math.sin(ga)
    vol = a * b * c * math.sqrt(max(1 - ca * ca - cb * cb - cg * cg
                                    + 2 * ca * cb * cg, 1e-12))
    m = np.array([
        [a, b * cg, c * cb],
        [0.0, b * sg, c * (ca - cb * cg) / sg],
        [0.0, 0.0, vol / (a * b * sg)],
    ])
    return m @ np.asarray(frac, float)


_GRID_N = 120


def _theta_grid(state):
    """벌점과 HARD 검사가 **같은 격자**를 봐야 한다.
    격자가 다르면 벌점은 0인데 검사는 위반을 잡아 단계가 통째로 롤백된다."""
    tth = state.two_theta
    th = np.radians(np.linspace(tth[0], tth[-1], _GRID_N) / 2.0)
    return th, np.tan(th), np.cos(th)


def penalty(state, weight: float | None = None) -> np.ndarray:
    """최소제곱 잔차에 더할 벌점 항.

    HARD 검사는 사후 거부라서, 최적화기가 금지 영역으로 걸어 들어가면
    단계 전체가 롤백돼 아무것도 못 배운다. 벌점은 최적화기를 **미리** 밀어낸다.
    허용 영역 안에서는 정확히 0 이므로 정상 정련을 왜곡하지 않는다.
    """
    if weight is None:
        # 데이터 규모에 맞춘다. 고정 상수를 쓰면 계수가 큰 패턴에서
        # 벌점이 잔차에 묻혀 아무 효과가 없다.
        w = 1.0 / np.sqrt(np.clip(state.yobs, 1.0, None))
        weight = 1e3 * float(np.linalg.norm(w * state.yobs)) + 1e3
    pen: list[float] = []
    _, t, ct = _theta_grid(state)
    for pm in state.models:
        p = pm.profile
        if p.tch:
            gg2 = (p.u * t ** 2 + p.v * t + p.w
                   + p.z / np.clip(ct ** 2, 1e-6, None))
            gl = p.x * t + p.y / np.clip(ct, 1e-6, None)
            pen.extend(np.maximum(1e-4 - gg2, 0.0) * weight)
            pen.extend(np.maximum(-gl, 0.0) * weight)
        else:
            fw2 = p.u * t ** 2 + p.v * t + p.w
            pen.extend(np.maximum(1e-4 - fw2, 0.0) * weight)
        ph = pm.phase
        a, b, c, al, be, ga = ph.cell_params
        ca, cb, cg = (math.cos(math.radians(x)) for x in (al, be, ga))
        det = 1 - ca * ca - cb * cb - cg * cg + 2 * ca * cb * cg
        pen.append(max(1e-6 - det, 0.0) * weight)
        pen.append(max(-pm.scale, 0.0) * weight)
    return np.asarray(pen, float)


def validate(state, *, prev_state=None, corr=None,
             cell_warn_pct: float = 2.0,
             corr_warn: float = 0.95) -> list[Check]:
    """정련 단계 후 상태를 검사한다.

    state      : RefinementState
    prev_state : 직전 상태 (차이 곡선 악화 판정용)
    corr       : 파라미터 상관행렬 (있을 때만)
    """
    out: list[Check] = []

    # ---------- HARD: 기계적으로 판정 가능한 위반 ----------
    vec = state.to_vector()[0]
    if not np.all(np.isfinite(vec)):
        out.append(Check("hard", "nonfinite", "정련 변수에 NaN/Inf가 있습니다."))
        return out

    for pm in state.models:
        ph = pm.phase
        if not _cell_is_valid(ph):
            out.append(Check("hard", "bad_cell",
                             f"[{ph.name}] 격자가 성립하지 않습니다 "
                             f"(부피 또는 각도 조합 불가)."))
            continue
        if ph.volume() <= 0:
            out.append(Check("hard", "bad_volume",
                             f"[{ph.name}] 단위포 부피가 0 이하입니다.",
                             ph.volume()))
        if pm.scale <= 0:
            out.append(Check("hard", "neg_scale",
                             f"[{ph.name}] 상 스케일이 0 이하입니다.", pm.scale))
        p = pm.profile
        # 측정 범위 전체에서 실제 FWHM > 0 인지 확인.
        # TCH 모드에서는 U,V,W 가 가우스 성분만 담당하므로 Caglioti 식이
        # 음수여도 전체 폭은 양수일 수 있다. 반드시 실제 폭 함수로 검사한다.
        _, t, ct = _theta_grid(state)
        if p.tch:
            gg2 = p.u * t ** 2 + p.v * t + p.w + p.z / np.clip(ct ** 2, 1e-6, None)
            gl = p.x * t + p.y / np.clip(ct, 1e-6, None)
            bad_w = (gg2 <= 0) | (gl < 0)
            worst = gg2
            msg = "TCH 가우스 폭²≤0 또는 로렌츠 폭<0"
        else:
            worst = p.u * t ** 2 + p.v * t + p.w
            bad_w = worst <= 0
            msg = "Caglioti U,V,W 가 FWHM²≤0 을 줍니다"
        if np.any(bad_w):
            bad = state.two_theta[0] + (state.two_theta[-1] -
                                        state.two_theta[0]) * \
                float(np.argmax(bad_w)) / (_GRID_N - 1.0)
            out.append(Check("hard", "neg_fwhm",
                             f"[{ph.name}] 2θ≈{bad:.1f}° 에서 {msg}.",
                             float(np.min(worst))))
        if not p.tch and not (0.0 <= p.eta0 <= 1.0):
            out.append(Check("hard", "eta_range",
                             f"[{ph.name}] pseudo-Voigt η가 [0,1] 밖입니다.",
                             p.eta0))
        if p.md <= 0:
            out.append(Check("hard", "md_range",
                             f"[{ph.name}] March-Dollase r이 0 이하입니다.",
                             p.md))
        for s in ph.sites:
            if not (0.0 < s.occ <= 1.0 + 1e-6):
                out.append(Check("hard", "occ_range",
                                 f"[{ph.name}] {s.label} 점유율 {s.occ:.3f} 가 "
                                 f"(0,1] 밖입니다.", s.occ))
            if s.biso < 0.0:
                out.append(Check("hard", "neg_biso",
                                 f"[{ph.name}] {s.label} B_iso 가 음수입니다 "
                                 f"({s.biso:.3f} Å²).", s.biso))

    if out:
        return out

    # ---------- WARN: 판단이 필요한 신호 ----------
    for pm in state.models:
        ph = pm.phase
        if ph.ref_cell:
            for i, nm in enumerate(["a", "b", "c"]):
                ref = ph.ref_cell[i]
                cur = ph.cell_params[i]
                if ref > 0:
                    dev = abs(cur - ref) / ref * 100.0
                    if dev > cell_warn_pct:
                        out.append(Check(
                            "warn", "cell_drift",
                            f"[{ph.name}] {nm} 가 참조 CIF 대비 {dev:.2f}% "
                            f"({ref:.4f} → {cur:.4f} Å) 벗어났습니다. "
                            f"영점/시료변위와 얽힐 수 있으니 함께 보십시오.", dev))
        for s in ph.sites:
            if s.biso > 8.0:
                out.append(Check("warn", "large_biso",
                                 f"[{ph.name}] {s.label} B_iso={s.biso:.2f} Å² 로 "
                                 f"큽니다. 점유율·스케일과 상관될 수 있습니다.",
                                 s.biso))
        try:
            for site, partner, r in min_bond_lengths(ph):
                lim = 0.75 * (_COV.get(site.element, 1.4) +
                              _COV.get(partner, 1.4))
                if r < lim:
                    out.append(Check(
                        "warn", "short_bond",
                        f"[{ph.name}] {site.element}–{partner} 최단거리 "
                        f"{r:.2f} Å 로 공유결합 반지름 합의 75%({lim:.2f} Å)보다 "
                        f"짧습니다.", r))
        except Exception:
            pass

    if corr is not None and corr.size:
        n = corr.shape[0]
        for i in range(n):
            for j in range(i + 1, n):
                c = corr[i, j]
                if abs(c) > corr_warn:
                    out.append(Check(
                        "warn", "high_corr",
                        f"{state.param_names[i]} ↔ {state.param_names[j]} "
                        f"상관 {c:+.3f}. 동시에 풀면 값이 서로를 흡수합니다.",
                        float(c)))

    if prev_state is not None:
        rn, ro = state.r_factors(), prev_state.r_factors()
        if rn["Rwp"] < ro["Rwp"] - 1e-9:
            dn = np.abs(state.yobs - state.ycalc())
            do = np.abs(prev_state.yobs - prev_state.ycalc())
            if float(np.max(dn)) > float(np.max(do)) * 1.05:
                out.append(Check(
                    "warn", "diff_worse",
                    f"Rwp는 {ro['Rwp']:.2f}→{rn['Rwp']:.2f} 로 좋아졌지만 "
                    f"차이 곡선 최대 잔차는 커졌습니다. 국소 불일치가 "
                    f"악화되는 중일 수 있습니다."))
    return out
