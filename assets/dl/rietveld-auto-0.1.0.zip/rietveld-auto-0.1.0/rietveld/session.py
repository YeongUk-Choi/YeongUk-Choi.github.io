"""정련 세션: 상태 + 이벤트 스트림 + AI 어드바이저.

AI는 엔진 안에 들어가지 않는다. 진단 JSON을 읽고 plan JSON을 만들 뿐이며,
plan 실행은 결정론적인 refine()이 한다. 모든 단계는 되돌릴 수 있다.
"""
from __future__ import annotations

import json
import os
import queue
import subprocess
import threading
import time

import numpy as np

from . import cod
from .pattern import Beam, PhaseModel, Sample
from .refine import RefinementState, refine
from .structure import read_cif


class EventBus:
    def __init__(self):
        self._subs: list[queue.Queue] = []
        self._lock = threading.Lock()
        self.history: list[dict] = []

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=200)
        with self._lock:
            self._subs.append(q)
        return q

    def unsubscribe(self, q) -> None:
        with self._lock:
            if q in self._subs:
                self._subs.remove(q)

    def emit(self, kind: str, **data) -> None:
        ev = {"kind": kind, "t": time.time(), **data}
        if kind in ("log", "step", "chat", "checks"):
            self.history.append(ev)
            del self.history[:-400]
        with self._lock:
            subs = list(self._subs)
        for q in subs:
            try:
                q.put_nowait(ev)
            except queue.Full:
                pass


class Session:
    def __init__(self):
        self.bus = EventBus()
        self.state: RefinementState | None = None
        self.candidates: list[dict] = []
        self.history: list[dict] = []      # 단계 기록 (스냅샷 포함)
        self.chat: list[dict] = []
        self.busy = False
        self.beam = Beam("Cu", use_ka2=True)

    # ------------------------------------------------------------------
    def log(self, msg: str, level: str = "info"):
        self.bus.emit("log", message=msg, level=level)

    def load_pattern(self, two_theta, yobs, name: str = "pattern"):
        self._tt = np.asarray(two_theta, float)
        self._yo = np.asarray(yobs, float)
        self.state = None
        self.log(f"패턴 로드: {name}, {len(self._tt)}점, "
                 f"{self._tt[0]:.2f}–{self._tt[-1]:.2f}°2θ, "
                 f"최대 {self._yo.max():.0f} counts")
        self.bus.emit("pattern", **self.plot_payload())

    def set_beam(self, anode="Cu", use_ka2=True, ratio=None):
        self.beam = Beam(anode, use_ka2, ratio)
        if self.state is not None:
            self.state.beam = self.beam
            self.state._ycache = None
        lines = self.beam.lines()
        self.log("선원: " + anode + " / " +
                 ("Kα1+Kα2" if use_ka2 else "Kα1 단독") + " → λ = " +
                 ", ".join(f"{l:.6f} Å (w={w:.3f})" for l, w in lines))
        self.push_state()

    def search_cod(self, formula: str, rank: bool = True):
        self.log(f"COD 검색: {formula}")
        cands = cod.search(formula)
        exact = [c for c in cands if c["ratio_ok"]]
        self.log(f"후보 {len(cands)}건 중 조성비 일치 {len(exact)}건")
        if rank and self.state is None and hasattr(self, "_tt"):
            self.log("후보별 계산 패턴과 관측 피크 위치를 비교하는 중…")
            exact = cod.rank_by_pattern(exact, self._tt, self._yo, self.beam)
        self.candidates = exact
        self.bus.emit("candidates", candidates=exact)
        return exact

    def use_phase(self, cod_id=None, cif_text=None, name=None, add=False):
        if cif_text is None:
            cif_text = cod.fetch_cif(cod_id)
            src = f"COD {cod_id}"
        else:
            src = name or "local CIF"
        ph = read_cif(cif_text, is_text=True, source=src)
        if name:
            ph.name = name
        pm = PhaseModel(phase=ph)
        if add and self.state is not None:
            models = self.state.models + [pm]
            sample = self.state.sample
            bkg = self.state.bkg_coef
        else:
            models, sample, bkg = [pm], Sample(), None
        self.state = RefinementState(self._tt, self._yo, models, self.beam,
                                     sample, bkg)
        # 스케일을 관측 강도에 맞춰 대략 맞춘다 (0에서 시작하면 안 움직인다)
        y = self.state.ycalc() - self.state.bkg_coef[0]
        pk = float(np.max(y))
        if pk > 0:
            k = float(np.max(self._yo) - np.percentile(self._yo, 5)) / pk
            pm.scale *= k * (0.02 if add else 1.0)
        self.state._ycache = None
        self.history = [{"label": "초기" if not add else f"{ph.name} 추가",
                         "snapshot": self.state.snapshot(),
                         "r": self.state.r_factors()}]
        self.log(f"상 설정: {ph.name} [{ph.spacegroup}] "
                 f"a={ph.a:.4f} b={ph.b:.4f} c={ph.c:.4f} β={ph.beta:.3f} "
                 f"— 반사 {len(pm.refl)}개, 자유 격자변수 "
                 f"{ph.free_cell_params()}, 출처 {src}")
        self.push_state()
        return ph

    # ------------------------------------------------------------------
    def plot_payload(self, max_pts: int = 2200):
        if self.state is None:
            tt, yo = getattr(self, "_tt", np.array([])), getattr(self, "_yo", np.array([]))
            yc = np.zeros_like(yo)
        else:
            tt, yo, yc = self.state.two_theta, self.state.yobs, self.state.ycalc()
        n = len(tt)
        step = max(1, n // max_pts)
        return {"x": tt[::step].round(4).tolist(),
                "obs": yo[::step].round(2).tolist(),
                "calc": yc[::step].round(2).tolist()}

    def status(self):
        s = {"has_pattern": hasattr(self, "_tt"),
             "has_phase": self.state is not None,
             "busy": self.busy,
             "beam": {"anode": self.beam.anode, "use_ka2": self.beam.use_ka2,
                      "lines": [[l, w] for l, w in self.beam.lines()]},
             "candidates": self.candidates,
             "history": [{"label": h["label"], "r": h["r"]}
                         for h in self.history]}
        if self.state is not None:
            st = self.state
            specs = st.specs()
            s["r"] = st.r_factors(len(st.param_names))
            s["params"] = [{"name": n, "label": sp.label, "kind": sp.kind,
                            "value": st.get(n), "lo": sp.lo, "hi": sp.hi}
                           for n, sp in specs.items()]
            s["phases"] = [{"name": pm.phase.name, "sg": pm.phase.spacegroup,
                            "source": pm.phase.source,
                            "cell": list(pm.phase.cell_params),
                            "free": pm.phase.free_cell_params(),
                            "nrefl": len(pm.refl)} for pm in st.models]
            fr = st.phase_fractions()
            for f, pm in zip(fr, st.models):
                if pm.fmul is not None:
                    f["weight_pct"] = None   # Le Bail 상은 정량 불가
                    f["lebail"] = True
            s["fractions"] = fr
        return s

    def push_state(self):
        self.bus.emit("state", status=self.status(), plot=self.plot_payload())

    # ------------------------------------------------------------------
    def run_plan(self, plan: list[dict]):
        """plan = [{'names': [...], 'label': '...', 'max_nfev': n}, ...]"""
        if self.state is None:
            self.log("상이 설정되지 않았습니다.", "error")
            return []
        self.busy = True
        results = []
        try:
            for i, step in enumerate(plan, 1):
                names = step["names"]
                label = step.get("label") or ", ".join(names[:3])
                self.bus.emit("step_start", index=i, total=len(plan),
                              label=label, names=names)

                last = [0.0]

                def prog(nfev, st):
                    now = time.time()
                    if now - last[0] > 0.25:
                        last[0] = now
                        self.bus.emit("progress", nfev=nfev,
                                      rwp=st.r_factors()["Rwp"],
                                      plot=self.plot_payload(900))

                r = refine(self.state, names,
                           max_nfev=int(step.get("max_nfev", 300)),
                           progress=prog)
                self.history.append({"label": label,
                                     "snapshot": self.state.snapshot(),
                                     "r": self.state.r_factors(len(names))})
                self.bus.emit("step", index=i, label=label,
                              result=r.as_dict())
                for c in r.checks:
                    self.log(f"[{c.level}] {c.message}",
                             "error" if c.level == "hard" else "warn")
                self.log(f"{label}: Rwp {r.r_before['Rwp']:.3f} → "
                         f"{r.r_after['Rwp']:.3f}" +
                         (f"  ※ {r.note}" if r.note else ""),
                         "warn" if r.rolled_back else "info")
                results.append(r.as_dict())
                self.push_state()
        finally:
            self.busy = False
            self.push_state()
        return results

    def lebail(self, phase_index: int = 0, cycles: int = 8,
               refine_cell: bool = True):
        """Le Bail 강도 추출. 구조를 모르는 상의 격자·프로파일만 알고 싶을 때 쓴다.

        주의: 강도를 데이터에서 뽑으므로 그 상의 **중량분율은 의미가 없다.**
        격자상수와 피크 폭만 신뢰할 수 있다.
        """
        from .refine import lebail_update
        if self.state is None:
            raise RuntimeError("상이 설정되지 않았습니다.")
        self.busy = True
        pre = f"p{phase_index}"
        try:
            for i in range(cycles):
                ch = lebail_update(self.state, phase_index)
                if refine_cell:
                    free = self.state.models[phase_index].phase.free_cell_params()
                    names = [f"{pre}.scale"] + [f"{pre}.{n}" for n in free] + \
                            [f"{pre}.W", f"{pre}.eta0"]
                    refine(self.state, names, max_nfev=200, allow_worse=True)
                r = self.state.r_factors()
                self.log(f"Le Bail {i+1}/{cycles}: Rwp={r['Rwp']:.3f} "
                         f"(최대 강도변화 {ch:.2f})")
                self.bus.emit("progress", nfev=i, rwp=r["Rwp"],
                              plot=self.plot_payload(900))
            self.history.append({"label": f"Le Bail ×{cycles}",
                                 "snapshot": self.state.snapshot(),
                                 "r": self.state.r_factors()})
        finally:
            self.busy = False
            self.push_state()
        return self.state.r_factors()

    def rollback(self, index: int):
        if not (0 <= index < len(self.history)):
            return False
        self.state.restore(self.history[index]["snapshot"])
        del self.history[index + 1:]
        self.log(f"'{self.history[index]['label']}' 시점으로 되돌렸습니다.",
                 "warn")
        self.push_state()
        return True

    # ------------------------------------------------------------------
    # AI 어드바이저
    # ------------------------------------------------------------------
    def diagnostics(self) -> dict:
        """AI에게 넘길 현재 상태 요약. 숫자만, 해석은 넣지 않는다."""
        d = {"beam": self.status()["beam"], "chat_len": len(self.chat)}
        if self.state is None:
            d["stage"] = "상 미설정"
            d["candidates"] = self.candidates[:8]
            return d
        st = self.state
        yo, yc = st.yobs, st.ycalc()
        diff = yo - yc
        n = 12
        edges = np.linspace(0, len(yo), n + 1).astype(int)
        worst = []
        for i in range(n):
            sl = slice(edges[i], edges[i + 1])
            if sl.stop <= sl.start:
                continue
            worst.append({
                "range": [round(float(st.two_theta[sl][0]), 2),
                          round(float(st.two_theta[sl][-1]), 2)],
                "max_abs_diff": round(float(np.max(np.abs(diff[sl]))), 1),
                "signed_mean": round(float(np.mean(diff[sl])), 1)})
        worst.sort(key=lambda w: -w["max_abs_diff"])
        d.update({
            "stage": "정련 중",
            "r": {k: round(v, 4) for k, v in st.r_factors().items()},
            "phases": self.status()["phases"],
            "params": {n_: round(st.get(n_), 6)
                       for n_ in st.specs() if not n_.startswith("bkg")},
            "worst_regions": worst[:5],
            "history": [{"label": h["label"], "Rwp": round(h["r"]["Rwp"], 3)}
                        for h in self.history],
            "refinable": list(st.specs().keys()),
        })
        return d

    def ask(self, message: str, backend: str | None = None) -> dict:
        backend = backend or os.environ.get("RIETVELD_AI", "claude")
        self.chat.append({"role": "user", "text": message})
        self.bus.emit("chat", role="user", text=message)
        try:
            out = _advise(message, self.diagnostics(), self.chat, backend)
        except Exception as exc:                      # noqa: BLE001
            out = {"reply": f"AI 호출 실패 ({backend}): {exc}\n"
                            f"오프라인 규칙으로 답합니다.\n\n" +
                            _rule_advice(self.diagnostics())["reply"],
                   "plan": _rule_advice(self.diagnostics())["plan"]}
        self.chat.append({"role": "assistant", "text": out["reply"],
                          "plan": out.get("plan")})
        self.bus.emit("chat", role="assistant", text=out["reply"],
                      plan=out.get("plan"))
        return out


SYSTEM = """당신은 분말 X선 리트벨트 정련을 지휘하는 과학 조수다.
사용자는 실험을 직접 한 연구자이므로, 시료·합성·측정 조건은 사용자가 더 잘 안다.

규칙:
- 한국어로, 짧고 구체적으로 답한다.
- 다음에 풀 변수를 제안할 때는 반드시 refinable 목록 안의 이름만 쓴다.
- 상관이 높은 변수(예: U,V,W 또는 zero,disp,격자상수)를 한 번에 다 풀라고 하지 않는다.
  풀어야 한다면 왜 괜찮은지 한 줄로 밝힌다.
- Rwp가 내려갔다는 이유만으로 좋은 정련이라고 말하지 않는다. 차이 곡선과
  물리적 타당성을 함께 언급한다.
- 확실하지 않으면 사용자에게 실험 조건을 묻는다(단색화기 유무, 시료 준비,
  예상 2차상, 측정 온도 등).

응답 형식: 사람이 읽을 설명을 쓰고, 정련을 제안할 때만 마지막에 아래 블록을 붙인다.
```plan
[{"label": "단계 이름", "names": ["p0.scale", "bkg.0"], "max_nfev": 300}]
```
"""


def _advise(message, diag, chat, backend) -> dict:
    prompt = (SYSTEM + "\n\n# 현재 상태(JSON)\n" +
              json.dumps(diag, ensure_ascii=False, default=str)[:12000] +
              "\n\n# 최근 대화\n" +
              "\n".join(f"{c['role']}: {c['text'][:600]}" for c in chat[-6:]) +
              f"\n\n# 사용자 메시지\n{message}\n")
    if backend == "rule":
        return _rule_advice(diag)
    cmd = ({"claude": ["claude", "-p", prompt],
            "codex": ["codex", "exec", prompt]})[backend]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    text = (p.stdout or p.stderr or "").strip()
    if not text:
        raise RuntimeError("빈 응답")
    return {"reply": _strip_plan(text), "plan": _extract_plan(text)}


def _extract_plan(text: str):
    import re
    m = re.search(r"```plan\s*(.+?)```", text, re.S)
    if not m:
        return None
    try:
        plan = json.loads(m.group(1))
        return plan if isinstance(plan, list) else None
    except json.JSONDecodeError:
        return None


def _strip_plan(text: str) -> str:
    import re
    return re.sub(r"```plan\s*.+?```", "", text, flags=re.S).strip()


def _rule_advice(diag) -> dict:
    """AI를 못 쓸 때의 보수적 대안. 판단이 아니라 정해진 순서다."""
    if diag.get("stage") != "정련 중":
        return {"reply": "먼저 패턴과 상(CIF)을 설정하십시오.", "plan": None}
    rwp = diag["r"]["Rwp"]
    ref = set(diag["refinable"])
    def keep(ns): return [n for n in ns if n in ref]
    if rwp > 30:
        step = {"label": "배경 + 스케일", "names": keep(
            ["bkg.0", "bkg.1", "bkg.2", "bkg.3", "p0.scale"])}
    elif rwp > 15:
        step = {"label": "영점 + 격자상수", "names": keep(
            ["p0.scale", "zero", "p0.a", "p0.b", "p0.c",
             "p0.alpha", "p0.beta", "p0.gamma"])}
    elif rwp > 10:
        step = {"label": "프로파일 W → U,V", "names": keep(
            ["p0.scale", "p0.W", "p0.eta0"])}
    else:
        step = {"label": "전체 미세 조정", "names": keep(
            ["p0.scale", "zero", "p0.a", "p0.b", "p0.c", "p0.beta",
             "p0.U", "p0.V", "p0.W", "p0.eta0",
             "bkg.0", "bkg.1", "bkg.2", "bkg.3"])}
    return {"reply": f"(오프라인 규칙) 현재 Rwp={rwp:.2f} 이므로 "
                     f"'{step['label']}' 단계를 제안합니다.", "plan": [step]}
