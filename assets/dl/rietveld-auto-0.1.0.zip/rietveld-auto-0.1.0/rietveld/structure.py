"""CIF -> 상(Phase) -> 반사(hkl, d, 다중도, |F|^2).

gemmi로 대칭 연산과 IT92 원자산란인자를 가져온다.
격자상수는 정련 대상이므로 hkl 목록과 d 계산을 분리해 둔다.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

import gemmi
import numpy as np

# u_iso -> B_iso
U_TO_B = 8.0 * math.pi ** 2


@dataclass
class Site:
    label: str
    element: str          # 전하를 뗀 중성 원소기호 (IT92 표 조회용)
    type_symbol: str      # CIF 원문 (예: 'V4+')
    x: float
    y: float
    z: float
    occ: float = 1.0
    biso: float = 0.5     # A^2


@dataclass
class Phase:
    name: str
    spacegroup: str
    a: float
    b: float
    c: float
    alpha: float
    beta: float
    gamma: float
    sites: list[Site] = field(default_factory=list)
    source: str = ""              # 출처 (COD ID / 파일 경로)
    ref_cell: tuple | None = None  # 참조 CIF의 원래 격자 (이탈 검사용)

    # --- 대칭 ---
    def sg(self) -> gemmi.SpaceGroup:
        sg = gemmi.find_spacegroup_by_name(self.spacegroup)
        if sg is None:
            raise ValueError(f"인식할 수 없는 공간군: {self.spacegroup!r}")
        return sg

    def cell(self) -> gemmi.UnitCell:
        return gemmi.UnitCell(self.a, self.b, self.c,
                              self.alpha, self.beta, self.gamma)

    @property
    def cell_params(self) -> tuple:
        return (self.a, self.b, self.c, self.alpha, self.beta, self.gamma)

    def volume(self) -> float:
        return self.cell().volume

    def free_cell_params(self) -> list[str]:
        """결정계가 허용하는 독립 격자 파라미터만 돌려준다.

        FullProf는 사용자가 실수로 정방정의 a,c를 따로 풀어도 막지 않는다.
        여기서는 공간군이 허용하지 않는 자유도를 애초에 만들지 않는다.
        """
        n = self.sg().number
        if n <= 2:                       # triclinic
            return ["a", "b", "c", "alpha", "beta", "gamma"]
        if n <= 15:                      # monoclinic (b unique)
            return ["a", "b", "c", "beta"]
        if n <= 74:                      # orthorhombic
            return ["a", "b", "c"]
        if n <= 142:                     # tetragonal
            return ["a", "c"]
        if n <= 167:                     # trigonal / rhombohedral
            hm = self.sg().hm
            return ["a", "alpha"] if hm.endswith(":R") else ["a", "c"]
        if n <= 194:                     # hexagonal
            return ["a", "c"]
        return ["a"]                     # cubic

    def apply_cell_symmetry(self) -> None:
        """자유롭지 않은 격자 파라미터를 대칭에 맞게 되돌린다."""
        free = set(self.free_cell_params())
        n = self.sg().number
        if n > 194:                                   # cubic
            self.b = self.c = self.a
            self.alpha = self.beta = self.gamma = 90.0
        elif n > 167 or (142 < n <= 167 and not self.sg().hm.endswith(":R")):
            self.b = self.a                            # hexagonal / trigonal P
            self.alpha = self.beta = 90.0
            self.gamma = 120.0
        elif 142 < n <= 167:                           # rhombohedral
            self.b = self.c = self.a
            self.beta = self.gamma = self.alpha
        elif n > 74:                                   # tetragonal
            self.b = self.a
            self.alpha = self.beta = self.gamma = 90.0
        elif n > 15:                                   # orthorhombic
            self.alpha = self.beta = self.gamma = 90.0
        elif n > 2:                                    # monoclinic
            self.alpha = self.gamma = 90.0
        if "alpha" not in free and n <= 142:
            pass


_CHARGE = re.compile(r"[0-9+\-.]+$")


def _neutral(symbol: str) -> str:
    return _CHARGE.sub("", symbol).strip() or "C"


def read_cif(path_or_text: str, *, is_text: bool = False,
             source: str = "") -> Phase:
    """COD CIF 또는 로컬 CIF를 Phase로 읽는다."""
    if is_text:
        doc = gemmi.cif.read_string(path_or_text)
        st = gemmi.make_small_structure_from_block(doc.sole_block())
    else:
        st = gemmi.read_small_structure(path_or_text)
    st.setup_cell_images()
    sites = []
    for s in st.sites:
        b = s.u_iso * U_TO_B if s.u_iso > 0 else 0.5
        sites.append(Site(label=s.label, element=_neutral(s.type_symbol),
                          type_symbol=s.type_symbol,
                          x=s.fract.x, y=s.fract.y, z=s.fract.z,
                          occ=s.occ if s.occ > 0 else 1.0, biso=b))
    c = st.cell
    ph = Phase(name=st.name or "phase", spacegroup=st.spacegroup_hm,
               a=c.a, b=c.b, c=c.c, alpha=c.alpha, beta=c.beta, gamma=c.gamma,
               sites=sites, source=source)
    ph.ref_cell = ph.cell_params
    return ph


# --------------------------------------------------------------------------
# 반사 목록
# --------------------------------------------------------------------------
@dataclass
class Reflections:
    hkl: np.ndarray        # (n,3) int, asu 대표
    mult: np.ndarray       # (n,) 다중도
    expanded: list         # 상별 전체 등가 위치 (구조인자용, 미리 전개)

    def __len__(self) -> int:
        return len(self.mult)


def generate_reflections(phase: Phase, d_min: float,
                         hkl_max: int = 24) -> Reflections:
    """d >= d_min 인 독립 반사와 다중도를 만든다. 소광조건 적용."""
    sg = phase.sg()
    ops = sg.operations()
    cell = phase.cell()
    seen: dict[tuple, int] = {}
    order: list[tuple] = []
    rng = range(-hkl_max, hkl_max + 1)
    for h in rng:
        for k in rng:
            for l in rng:
                if h == 0 and k == 0 and l == 0:
                    continue
                inv_d2 = cell.calculate_1_d2([h, k, l])
                if inv_d2 <= 0 or 1.0 / math.sqrt(inv_d2) < d_min:
                    continue
                if ops.is_systematically_absent([h, k, l]):
                    continue
                key = _asu_key(ops, (h, k, l))
                if key not in seen:
                    seen[key] = 0
                    order.append(key)
                seen[key] += 1
    hkl = np.array(order, dtype=int)
    mult = np.array([seen[k] for k in order], dtype=float)
    return Reflections(hkl=hkl, mult=mult, expanded=expand_sites(phase))


def _asu_key(ops, hkl):
    """등가 반사(Friedel 포함) 중 사전순 최대를 대표로 쓴다."""
    best = None
    for op in ops:
        e = tuple(op.apply_to_hkl(list(hkl)))
        for cand in (e, tuple(-v for v in e)):
            if best is None or cand > best:
                best = cand
    return best


def expand_sites(phase: Phase):
    """비대칭 단위 원자를 단위포 전체로 전개 (중복 제거)."""
    ops = list(phase.sg().operations())
    out = []
    for s in phase.sites:
        pos = []
        for op in ops:
            p = op.apply_to_xyz([s.x, s.y, s.z])
            p = tuple(round(v % 1.0, 5) for v in p)
            if all(sum((p[i] - q[i]) ** 2 for i in range(3)) > 1e-6
                   for q in pos):
                pos.append(p)
        out.append((s, np.array(pos)))
    return out


_FF_CACHE: dict[str, object] = {}


def _ff(element: str):
    if element not in _FF_CACHE:
        _FF_CACHE[element] = gemmi.Element(element).it92
    return _FF_CACHE[element]


def structure_factors(phase: Phase, refl: Reflections,
                      stol: np.ndarray) -> np.ndarray:
    """|F(hkl)|^2. stol = sin(theta)/lambda = 1/(2d)."""
    hkl = refl.hkl
    stol2 = stol ** 2
    F = np.zeros(len(hkl), dtype=complex)
    for site, pos in refl.expanded:
        f = np.array([_ff(site.element).calculate_sf(s2) for s2 in stol2])
        dw = np.exp(-site.biso * stol2)          # exp(-B (sin t/lam)^2)
        phase_sum = np.zeros(len(hkl), dtype=complex)
        for p in pos:
            arg = 2.0 * np.pi * (hkl @ p)
            phase_sum += np.exp(1j * arg)
        F += site.occ * f * dw * phase_sum
    return np.abs(F) ** 2
