"""rietveld-auto: AI 지휘형 리트벨트 정련 엔진.

설계 원칙
---------
엔진은 결정론적이다. AI는 엔진 안이 아니라 위에 있다.
AI는 `plan`(JSON)을 만들고 `RefinementResult`(JSON)를 읽을 뿐이며,
모든 단계는 스냅샷으로 남아 되돌릴 수 있다.
"""
__version__ = "0.1.0"
