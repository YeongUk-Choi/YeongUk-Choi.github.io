"""AI 에이전트용 명령줄 인터페이스.

모든 명령은 JSON 한 덩어리를 표준출력으로 낸다. Claude Code · Codex · 그 밖의
어떤 에이전트든 셸에서 호출해 같은 결론을 재현하고 서로 검증할 수 있다.

    python -m rietveld.cli search   --formula VO2
    python -m rietveld.cli index    --data pattern.xy
    python -m rietveld.cli analyze  --data pattern.xy --cod 7231905 \
                                    --impurity PbCl2,CsCl --lebail-pnma 5.684
    python -m rietveld.cli serve    --port 8765

종료 코드: 0 정상, 1 사용자 오류, 2 네트워크, 4 그 밖.
"""
from __future__ import annotations

import argparse
import json
import sys
import warnings

import numpy as np

warnings.filterwarnings("ignore")


def _out(obj, code: int = 0):
    def enc(o):
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            v = float(o)
            return None if v != v or abs(v) == float("inf") else v
        if isinstance(o, np.ndarray):
            return o.tolist()
        return str(o)
    print(json.dumps(obj, ensure_ascii=False, indent=2, default=enc))
    sys.exit(code)


def cmd_search(a):
    from .cod import search
    r = search(a.formula, strict_nel=not a.loose)
    _out({"command": "search", "formula": a.formula,
          "n_total": len(r),
          "n_ratio_ok": sum(1 for c in r if c["ratio_ok"]),
          "candidates": r[: a.limit],
          "note": ("COD 의 조성 문자열은 표기가 제각각이라 el1..elN + nel 로 "
                   "받아온 뒤 조성비를 이쪽에서 거른다. ratio_ok=false 는 "
                   "원소는 같지만 비가 다른 상(예: VO2 검색의 V5O9)이다.")})


def cmd_index(a):
    from .diagnose import geometry_model, index_cubic
    from .server import read_xy
    tt, y = read_xy(a.data)
    lam = 1.540598 if a.anode == "Cu" else None
    from .pattern import SOURCES
    lam = SOURCES[a.anode]["ka1"]
    idx = index_cubic(tt, y, lam=lam, prominence=a.prominence)
    res = {"command": "index", "data": a.data,
           "range_deg": [round(float(tt[0]), 3), round(float(tt[-1]), 3)],
           "n_points": int(len(tt)), "index": idx}
    if idx.get("indexed_two_theta"):
        res["geometry"] = geometry_model(idx["indexed_two_theta"],
                                         idx["indexed_n"], lam=lam)
    _out(res)


def _load_state(a):
    from .cod import fetch_cif
    from .pattern import Beam, PhaseModel
    from .refine import RefinementState
    from .server import read_xy
    from .structure import read_cif
    tt, yo = read_xy(a.data)
    ph = read_cif(fetch_cif(a.cod), is_text=True, source=f"COD {a.cod}")
    ph.name = a.name or f"COD {a.cod}"
    pm = PhaseModel(phase=ph)
    if a.tch:
        pm.profile.tch = True
        pm.profile.u, pm.profile.v, pm.profile.w = 0.002, 0.0, 0.002
        pm.profile.x, pm.profile.y = 0.06, 0.02
    st = RefinementState(tt, yo, [pm], Beam(a.anode, use_ka2=not a.ka1))
    y = st.ycalc() - st.bkg_coef[0]
    pm.scale *= (yo.max() - np.percentile(yo, 5)) / max(float(y.max()), 1e-9)
    st._ycache = None
    return st, pm


def _auto_plan(st, tch: bool, asym: bool, pre="p0"):
    prof = [f"{pre}.U", f"{pre}.V", f"{pre}.W"] + \
           ([f"{pre}.X", f"{pre}.Y"] if tch else [f"{pre}.eta0"])
    asy = [f"{pre}.asy1", f"{pre}.asy2"] if asym else []
    specs = st.specs()
    cell = [f"{pre}.{n}" for n in st.models[0].phase.free_cell_params()]
    atoms = [n for n in specs if n.endswith(".biso") and n.startswith(pre)]
    bkg = [n for n in specs if n.startswith("bkg.")]
    return [("배경", bkg),
            ("배경+스케일", [f"{pre}.scale"] + bkg),
            ("영점", [f"{pre}.scale", "zero"] + bkg),
            ("격자상수", [f"{pre}.scale", "zero"] + cell),
            ("프로파일", [f"{pre}.scale"] + prof),
            ("비대칭", [f"{pre}.scale"] + prof + asy) if asym else None,
            ("B_iso", [f"{pre}.scale"] + atoms),
            ("전체", [f"{pre}.scale", "zero"] + cell + prof + asy + atoms + bkg)]


def _pick_md_axis(st, phase_index: int = 0):
    """우선방위 축을 데이터가 고르게 한다.

    March-Dollase 축은 정련 변수가 아니라 **모델 선택**이다. 후보 축마다
    obs/calc 편차와의 상관을 보고 가장 잘 설명하는 축을 고른다.
    """
    from .diagnose import texture_test
    axes = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1),
            (0, 1, 1), (1, 1, 1)]
    t = texture_test(st, phase_index, axes=tuple(axes))
    if not t.get("axes"):
        return None, t
    best = t["axes"][0]
    return tuple(best["axis"]), t


def cmd_analyze(a):
    from .cod import pnma_template_cif
    from .diagnose import eliminate
    from .pattern import PhaseModel
    from .refine import RefinementState, lebail_update, refine
    from .structure import read_cif
    st, pm = _load_state(a)
    steps = []
    md_info = None
    if a.md_hkl:
        pm.profile.md_hkl = tuple(int(v) for v in a.md_hkl.split(","))

    def do(label, names, worse=False):
        names = [n for n in names if n in st.specs()]
        if not names:
            return
        r = refine(st, names,
                   max_nfev=a.max_nfev * (3 if label == "전체" else 1),
                   allow_worse=worse)
        steps.append({"step": label, "names": names,
                      "Rwp_before": round(r.r_before["Rwp"], 4),
                      "Rwp_after": round(r.r_after["Rwp"], 4),
                      "rolled_back": r.rolled_back, "note": r.note,
                      "warnings": [c.message for c in r.checks
                                   if c.level == "warn"]})

    for item in _auto_plan(st, a.tch, a.asymmetry):
        if item is None:
            continue
        label, names = item
        if label == "전체":
            if a.md_auto or a.md_hkl:
                if a.md_auto:
                    ax, t = _pick_md_axis(st)
                    md_info = {"chosen_axis": list(ax) if ax else None,
                               "candidates": t.get("axes"),
                               "note": ("축은 정련 변수가 아니라 모델 선택이다. "
                                        "obs/calc 편차와 가장 상관이 높은 축을 "
                                        "골랐을 뿐이므로, 시료 형태(벽개면·"
                                        "판상 여부)와 맞는지 사람이 확인하라.")}
                    if ax:
                        pm.profile.md_hkl = ax
                do("우선방위 MD", [f"p0.scale", "p0.md"], worse=True)
                names = names + ["p0.md"]
        if label == "전체":
            # 마지막 통합 단계는 변수가 많아 한 번으로는 수렴하지 않는다.
            # 실측·합성 모두에서 2회 반복 때 더 나은 골짜기로 넘어갔다.
            for _ in range(2):
                do(label, names, worse=True)
        else:
            do(label, names, worse=label in ("프로파일", "비대칭"))
    result = {"command": "analyze", "data": a.data, "cod": a.cod,
              "preferred_orientation": md_info,
              "beam": {"anode": a.anode, "use_ka2": not a.ka1},
              "profile": "TCH" if a.tch else "pseudo-Voigt",
              "steps": steps}
    # Le Bail 2차상
    if a.lebail_scan:
        import copy as _copy
        starts = [float(v) for v in a.lebail_scan.split(",")]
        runs = []
        base_snapshot = st.snapshot()
        for apc in starts:
            st_base = _copy.deepcopy(st)
            st_base.restore(base_snapshot)
            runs.append(_lebail_run(st_base, a, apc))
        runs.sort(key=lambda r: r["Rwp"])
        best = runs[0]
        spread = max(r["Rwp"] for r in runs) - best["Rwp"]
        distinct = [r for r in runs if r["Rwp"] < best["Rwp"] + 0.3]
        result["lebail_scan"] = {
            "starts": starts, "runs": runs, "best": best,
            "Rwp_spread": round(spread, 3),
            "verdict": (
                f"시작값 {len(starts)}개 중 최저 Rwp={best['Rwp']:.3f} 해가 "
                f"{len(distinct)}개 시작에서 재현된다. "
                + (f"Rwp 폭이 {spread:.2f} 로 크다 — **서로 다른 극소가 여럿 "
                   f"있다.** 격자를 확정했다고 말하지 마라. 고각까지 측정 범위를 "
                   f"넓혀야 갈린다." if spread > 0.3 else
                   "모든 시작이 같은 해로 모였다 — 격자를 신뢰할 만하다."))}
        _out(result)
    if a.lebail_pnma:
        ph2 = read_cif(pnma_template_cif(*a.lebail_atoms.split(","),
                                         a_pc=a.lebail_pnma),
                       is_text=True, source="Pnma 템플릿")
        ph2.name = "2차상 (Pnma 템플릿, Le Bail)"
        pm2 = PhaseModel(phase=ph2)
        st2 = RefinementState(st.two_theta, st.yobs, st.models + [pm2],
                              st.beam, st.sample, st.bkg_coef)
        y = st2.ycalc() - st2.bkg_coef[0]
        pm2.scale *= 0.02 * (st.yobs.max() - np.percentile(st.yobs, 5)) / \
            max(float(y.max()), 1e-9)
        st2._ycache = None
        lb = []
        p1 = ["p1.scale", "p1.a", "p1.b", "p1.c", "p1.W", "p1.eta0"]
        # 2차상 강도를 뽑은 뒤 주상을 다시 풀고, 다시 뽑는다.
        # 한 방향으로만 가면 주상이 옛 배경·폭에 묶여 Rwp 가 남는다.
        cubic_full = [n for n in
                      (["p0.scale", "zero"]
                       + [f"p0.{n}" for n in st.models[0].phase.free_cell_params()]
                       + ["p0.U", "p0.V", "p0.W", "p0.eta0", "p0.X", "p0.Y",
                          "p0.asy1", "p0.asy2"]
                       + [n for n in st2.specs() if n.startswith("p0.")
                          and n.endswith(".biso")]
                       + [n for n in st2.specs() if n.startswith("bkg.")])
                      if n in st2.specs()]
        for rnd in range(2):
            for _ in range(a.lebail_cycles):
                lebail_update(st2, 1)
                refine(st2, p1, max_nfev=200, allow_worse=True)
                lb.append(round(st2.r_factors()["Rwp"], 4))
            refine(st2, cubic_full, max_nfev=a.max_nfev * 3, allow_worse=True)
            lb.append(round(st2.r_factors()["Rwp"], 4))
        st = st2
        result["lebail"] = {
            "cycles": a.lebail_cycles, "Rwp_trace": lb,
            "cell": [round(v, 4) for v in ph2.cell_params[:3]],
            "pseudo_cubic": [round(ph2.a / 2 ** .5, 4), round(ph2.b / 2, 4),
                             round(ph2.c / 2 ** .5, 4)],
            "note": ("Le Bail 은 강도를 데이터에서 뽑는다. 격자상수와 피크 폭만 "
                     "신뢰하라. **중량분율은 정의되지 않는다.**")}
    rf = st.r_factors(len(st.param_names))
    result["r_factors"] = {k: round(v, 4) for k, v in rf.items()}
    result["phases"] = [{"name": m.phase.name, "spacegroup": m.phase.spacegroup,
                         "cell": [round(v, 5) for v in m.phase.cell_params],
                         "lebail": m.fmul is not None} for m in st.models]
    result["zero_deg"] = round(st.sample.zero, 5)
    if a.diagnose:
        imp = a.impurity.split(",") if a.impurity else None
        result["diagnosis"] = eliminate(st, 0, imp)
    _out(result)


def _lebail_run(st, a, apc: float) -> dict:
    """한 시작값에서 Le Bail 2차상을 붙여 돌리고 결과 요약만 돌려준다."""
    from .cod import pnma_template_cif
    from .pattern import PhaseModel
    from .refine import RefinementState, lebail_update, refine
    from .structure import read_cif
    ph2 = read_cif(pnma_template_cif(*a.lebail_atoms.split(","), a_pc=apc),
                   is_text=True, source="Pnma 템플릿")
    ph2.name = f"2차상 (a_pc={apc})"
    pm2 = PhaseModel(phase=ph2)
    st2 = RefinementState(st.two_theta, st.yobs, st.models + [pm2],
                          st.beam, st.sample, st.bkg_coef)
    y = st2.ycalc() - st2.bkg_coef[0]
    pm2.scale *= 0.02 * (st.yobs.max() - np.percentile(st.yobs, 5)) / \
        max(float(y.max()), 1e-9)
    st2._ycache = None
    p1 = ["p1.scale", "p1.a", "p1.b", "p1.c", "p1.W", "p1.eta0"]
    cubic = [n for n in (["p0.scale", "zero"]
                         + [f"p0.{n}" for n in st.models[0].phase.free_cell_params()]
                         + ["p0.U", "p0.V", "p0.W", "p0.eta0", "p0.asy1", "p0.asy2"]
                         + [n for n in st2.specs() if n.startswith("bkg.")])
             if n in st2.specs()]
    for _ in range(2):
        for _ in range(a.lebail_cycles):
            lebail_update(st2, 1)
            refine(st2, p1, max_nfev=200, allow_worse=True)
        refine(st2, cubic, max_nfev=a.max_nfev * 2, allow_worse=True)
    return {"start_a_pc": apc,
            "Rwp": round(st2.r_factors()["Rwp"], 4),
            "cell": [round(v, 4) for v in ph2.cell_params[:3]],
            "pseudo_cubic": sorted(round(v, 4) for v in
                                   (ph2.a / 2 ** .5, ph2.b / 2, ph2.c / 2 ** .5)),
            "cubic_a": round(st2.models[0].phase.a, 5)}


def cmd_serve(a):
    from . import server
    sys.argv = ["rietveld", "--port", str(a.port)] + \
               (["--data", a.data] if a.data else [])
    server.main()


def main(argv=None):
    ap = argparse.ArgumentParser("rietveld", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("search", help="COD 검색")
    s.add_argument("--formula", required=True)
    s.add_argument("--loose", action="store_true", help="원소 개수 제한 해제")
    s.add_argument("--limit", type=int, default=20)
    s.set_defaults(func=cmd_search)

    s = sub.add_parser("index", help="CIF 없이 자동 지수화 + 기하 모델 선택")
    s.add_argument("--data", required=True)
    s.add_argument("--anode", default="Cu")
    s.add_argument("--prominence", type=float, default=0.008)
    s.set_defaults(func=cmd_index)

    s = sub.add_parser("analyze", help="정련 + 진단 한 번에")
    s.add_argument("--data", required=True)
    s.add_argument("--cod", required=True)
    s.add_argument("--name", default=None)
    s.add_argument("--anode", default="Cu")
    s.add_argument("--ka1", action="store_true", help="Kα1 단독 (단색화기)")
    s.add_argument("--tch", action="store_true", help="TCH 프로파일")
    s.add_argument("--asymmetry", action="store_true", help="비대칭 정련")
    s.add_argument("--md-hkl", default=None, metavar="h,k,l",
                   help="March-Dollase 우선방위 축을 직접 지정")
    s.add_argument("--md-auto", action="store_true",
                   help="우선방위 축을 데이터가 고르게 한다")
    s.add_argument("--max-nfev", type=int, default=400)
    s.add_argument("--lebail-pnma", type=float, default=None,
                   metavar="A_PC", help="Pnma 2차상을 이 유사입방 값으로 추가")
    s.add_argument("--lebail-atoms", default="Cs,Pb,Cl")
    s.add_argument("--lebail-cycles", type=int, default=14)
    s.add_argument("--lebail-scan", default=None, metavar="a1,a2,...",
                   help="여러 시작 유사입방값에서 Le Bail 을 돌려 극소가 "
                        "하나인지 확인한다 (격자 확정 주장 전에 반드시)")
    s.add_argument("--impurity", default=None,
                   help="배제 검정할 조성 목록 (쉼표 구분)")
    s.add_argument("--no-diagnose", dest="diagnose", action="store_false")
    s.set_defaults(func=cmd_analyze, diagnose=True)

    s = sub.add_parser("serve", help="웹 화면 실행")
    s.add_argument("--port", type=int, default=8765)
    s.add_argument("--data", default=None)
    s.set_defaults(func=cmd_serve)

    a = ap.parse_args(argv)
    try:
        a.func(a)
    except SystemExit:
        raise
    except FileNotFoundError as exc:
        _out({"error": "user_error", "message": str(exc)}, 1)
    except OSError as exc:
        _out({"error": "network", "message": str(exc)}, 2)
    except Exception as exc:                            # noqa: BLE001
        import traceback
        _out({"error": type(exc).__name__, "message": str(exc),
              "traceback": traceback.format_exc()[-1500:]}, 4)


if __name__ == "__main__":
    main()
