"""정련 상태, 파라미터 레지스트리, 최소제곱 정련, 스냅샷/롤백.

엔진은 결정론적이다. 어떤 변수를 풀지는 바깥(사람 또는 AI)이 정하고,
여기서는 정한 대로 풀고 결과와 불확도·상관을 돌려준다.
"""
from __future__ import annotations

import copy
import math
from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import least_squares

from .pattern import (Beam, PhaseModel, ProfileParams, Sample, calc_pattern,
                      r_factors)
from .physics import penalty, validate
from .structure import generate_reflections


@dataclass
class ParamSpec:
    name: str
    lo: float
    hi: float
    kind: str          # 'bkg' | 'inst' | 'scale' | 'cell' | 'profile' | 'atom'
    label: str = ""    # 사람이 읽는 이름


class RefinementState:
    """관측 패턴 + 모델 + 파라미터 접근자."""

    def __init__(self, two_theta, yobs, models: list[PhaseModel],
                 beam: Beam, sample: Sample | None = None,
                 bkg_coef=None, d_min: float | None = None):
        self.two_theta = np.asarray(two_theta, float)
        self.yobs = np.asarray(yobs, float)
        self.models = models
        self.beam = beam
        self.sample = sample or Sample()
        if bkg_coef is None:
            bkg_coef = [float(np.percentile(self.yobs, 5)), 0.0, 0.0, 0.0]
        self.bkg_coef = list(map(float, bkg_coef))
        lam = beam.lines()[0][0]
        tmax = math.radians(self.two_theta[-1] / 2.0)
        self.d_min = d_min or lam / (2.0 * math.sin(tmax)) * 0.995
        for pm in self.models:
            if pm.refl is None:
                pm.refl = generate_reflections(pm.phase, self.d_min)
        self._ycache = None

    # ------------------------------------------------------------------
    # 파라미터 레지스트리
    # ------------------------------------------------------------------
    def specs(self) -> dict[str, ParamSpec]:
        s: dict[str, ParamSpec] = {}
        ymax = float(np.max(self.yobs)) or 1.0
        for i in range(len(self.bkg_coef)):
            s[f"bkg.{i}"] = ParamSpec(f"bkg.{i}", -5 * ymax, 5 * ymax,
                                      "bkg", f"배경 계수 {i}")
        s["zero"] = ParamSpec("zero", -0.5, 0.5, "inst", "영점 (°2θ)")
        s["disp"] = ParamSpec("disp", -0.5, 0.5, "inst", "시료 변위")
        s["transp"] = ParamSpec("transp", -0.5, 0.5, "inst", "투과")
        for i, pm in enumerate(self.models):
            ph, p = pm.phase, pm.profile
            pre = f"p{i}"
            s[f"{pre}.scale"] = ParamSpec(f"{pre}.scale", 1e-12, 1e12,
                                          "scale", f"{ph.name} 스케일")
            for nm in ph.free_cell_params():
                v = getattr(ph, nm)
                if nm in ("a", "b", "c"):
                    lo, hi = v * 0.90, v * 1.10
                else:
                    lo, hi = max(v - 8.0, 1.0), min(v + 8.0, 179.0)
                s[f"{pre}.{nm}"] = ParamSpec(f"{pre}.{nm}", lo, hi, "cell",
                                             f"{ph.name} {nm}")
            s[f"{pre}.U"] = ParamSpec(f"{pre}.U", 0.0, 2.0, "profile",
                                      f"{ph.name} Caglioti U")
            s[f"{pre}.V"] = ParamSpec(f"{pre}.V", -1.0, 1.0, "profile",
                                      f"{ph.name} Caglioti V")
            s[f"{pre}.W"] = ParamSpec(f"{pre}.W", 1e-6, 2.0, "profile",
                                      f"{ph.name} Caglioti W")
            s[f"{pre}.eta0"] = ParamSpec(f"{pre}.eta0", 0.0, 1.0, "profile",
                                         f"{ph.name} η₀")
            s[f"{pre}.eta1"] = ParamSpec(f"{pre}.eta1", -0.01, 0.01,
                                         "profile", f"{ph.name} η₁")
            s[f"{pre}.md"] = ParamSpec(f"{pre}.md", 0.2, 5.0, "profile",
                                       f"{ph.name} March-Dollase r")
            s[f"{pre}.X"] = ParamSpec(f"{pre}.X", 0.0, 1.0, "profile",
                                      f"{ph.name} TCH X (미세변형)")
            s[f"{pre}.Y"] = ParamSpec(f"{pre}.Y", 0.0, 1.0, "profile",
                                      f"{ph.name} TCH Y (결정립 크기)")
            s[f"{pre}.Z"] = ParamSpec(f"{pre}.Z", 0.0, 1.0, "profile",
                                      f"{ph.name} TCH Z")
            for k in (1, 2, 3, 4):
                s[f"{pre}.asy{k}"] = ParamSpec(f"{pre}.asy{k}", -1.0, 1.0,
                                               "profile",
                                               f"{ph.name} 비대칭 Asy{k}")
            for st in ph.sites:
                b = f"{pre}.{st.label}"
                for ax in "xyz":
                    s[f"{b}.{ax}"] = ParamSpec(f"{b}.{ax}", -2.0, 2.0,
                                               "atom", f"{st.label} {ax}")
                s[f"{b}.occ"] = ParamSpec(f"{b}.occ", 1e-4, 1.0, "atom",
                                          f"{st.label} 점유율")
                s[f"{b}.biso"] = ParamSpec(f"{b}.biso", 0.0, 20.0, "atom",
                                           f"{st.label} B_iso")
        return s

    def get(self, name: str) -> float:
        if name.startswith("bkg."):
            return self.bkg_coef[int(name.split(".")[1])]
        if name in ("zero", "disp", "transp"):
            return getattr(self.sample, {"zero": "zero", "disp": "displacement",
                                         "transp": "transparency"}[name])
        parts = name.split(".")
        pm = self.models[int(parts[0][1:])]
        if parts[1] == "scale":
            return pm.scale
        if len(parts) == 2:
            if parts[1] in ("U", "V", "W", "X", "Y", "Z"):
                return getattr(pm.profile, parts[1].lower())
            if parts[1] in ("eta0", "eta1", "md") or parts[1].startswith("asy"):
                return getattr(pm.profile, parts[1])
            return getattr(pm.phase, parts[1])
        site = next(s for s in pm.phase.sites if s.label == parts[1])
        return getattr(site, parts[2])

    def set(self, name: str, value: float) -> None:
        self._ycache = None
        if name.startswith("bkg."):
            self.bkg_coef[int(name.split(".")[1])] = float(value)
            return
        if name in ("zero", "disp", "transp"):
            setattr(self.sample, {"zero": "zero", "disp": "displacement",
                                  "transp": "transparency"}[name], float(value))
            return
        parts = name.split(".")
        pm = self.models[int(parts[0][1:])]
        if parts[1] == "scale":
            pm.scale = float(value)
            return
        if len(parts) == 2:
            if parts[1] in ("U", "V", "W", "X", "Y", "Z"):
                setattr(pm.profile, parts[1].lower(), float(value))
            elif parts[1] in ("eta0", "eta1", "md") or parts[1].startswith("asy"):
                setattr(pm.profile, parts[1], float(value))
            else:
                setattr(pm.phase, parts[1], float(value))
                pm.phase.apply_cell_symmetry()
            return
        site = next(s for s in pm.phase.sites if s.label == parts[1])
        setattr(site, parts[2], float(value))
        if parts[2] in "xyz":
            pm.refl.expanded = None  # 좌표가 바뀌면 전개 갱신 필요
            from .structure import expand_sites
            pm.refl.expanded = expand_sites(pm.phase)

    # ------------------------------------------------------------------
    def to_vector(self, names=None):
        names = list(names or self.specs().keys())
        return np.array([self.get(n) for n in names], float), names

    @property
    def param_names(self):
        return getattr(self, "_active", [])

    def ycalc(self):
        if self._ycache is None:
            self._ycache = calc_pattern(self.two_theta, self.models,
                                        self.beam, self.sample, self.bkg_coef)
        return self._ycache

    def peaks(self):
        _, pk = calc_pattern(self.two_theta, self.models, self.beam,
                             self.sample, self.bkg_coef, return_peaks=True)
        return pk

    def r_factors(self, n_par: int = 0):
        return r_factors(self.yobs, self.ycalc(), n_par)

    # ------------------------------------------------------------------
    def snapshot(self) -> dict:
        names = list(self.specs().keys())
        return {n: self.get(n) for n in names}

    def restore(self, snap: dict) -> None:
        for n, v in snap.items():
            try:
                self.set(n, v)
            except Exception:
                pass
        self._ycache = None

    def phase_fractions(self) -> list[dict]:
        """Hill-Howard 방식 중량 분율. Z·M은 CIF 자리 점유에서 추정한다."""
        import gemmi
        out, tot = [], 0.0
        for pm in self.models:
            ph = pm.phase
            mass = 0.0
            for site, pos in pm.refl.expanded:
                mass += site.occ * len(pos) * \
                    gemmi.Element(site.element).weight
            zmv = mass * ph.volume()
            w = pm.scale * zmv
            out.append({"phase": ph.name, "_w": w, "cell_mass": mass,
                        "volume": ph.volume()})
            tot += w
        for o in out:
            o["weight_pct"] = 100.0 * o.pop("_w") / tot if tot > 0 else 0.0
        return out


# ----------------------------------------------------------------------
@dataclass
class StepResult:
    ok: bool
    names: list[str]
    before: dict
    after: dict
    r_before: dict
    r_after: dict
    esd: dict = field(default_factory=dict)
    corr: list = field(default_factory=list)
    checks: list = field(default_factory=list)
    rolled_back: bool = False
    note: str = ""
    nfev: int = 0

    def as_dict(self):
        return {"ok": self.ok, "names": self.names,
                "r_before": self.r_before, "r_after": self.r_after,
                "changed": {n: [self.before[n], self.after[n]]
                            for n in self.names},
                "esd": self.esd, "checks": [c.as_dict() for c in self.checks],
                "rolled_back": self.rolled_back, "note": self.note,
                "nfev": self.nfev}


def refine(state: RefinementState, names: list[str], *, max_nfev: int = 300,
           allow_worse: bool = False, progress=None) -> StepResult:
    """지정한 변수만 푼다. 위반이나 악화가 나오면 되돌린다."""
    specs = state.specs()
    unknown = [n for n in names if n not in specs]
    if unknown:
        raise KeyError(f"모르는 변수: {unknown}")
    state._active = list(names)
    snap = state.snapshot()
    r_before = state.r_factors(len(names))
    lo = np.array([specs[n].lo for n in names])
    hi = np.array([specs[n].hi for n in names])
    x0 = np.clip(np.array([state.get(n) for n in names], float),
                 lo + 1e-12, hi - 1e-12)
    w = 1.0 / np.sqrt(np.clip(state.yobs, 1.0, None))
    calls = {"n": 0}

    def resid(x):
        for n, v in zip(names, x):
            state.set(n, v)
        y = state.ycalc()
        calls["n"] += 1
        if progress is not None and calls["n"] % 8 == 0:
            progress(calls["n"], state)
        base = w * (state.yobs - y)
        pen = penalty(state)
        return np.concatenate([base, pen]) if pen.size else base

    try:
        res = least_squares(resid, x0, bounds=(lo, hi), max_nfev=max_nfev,
                            xtol=1e-10, ftol=1e-10)
    except Exception as exc:                      # noqa: BLE001
        state.restore(snap)
        return StepResult(False, names, snap, snap, r_before, r_before,
                          rolled_back=True, note=f"최적화 실패: {exc}")
    for n, v in zip(names, res.x):
        state.set(n, v)

    sig, corr = _esd_and_corr(res, len(state.yobs), len(names))
    esd = {n: sig.get(i, float('nan')) for i, n in enumerate(names)}
    checks = validate(state, corr=corr)
    after = state.snapshot()
    r_after = state.r_factors(len(names))
    hard = [c for c in checks if c.level == "hard"]
    worse = r_after["Rwp"] > r_before["Rwp"] + 1e-6
    if hard or (worse and not allow_worse):
        state.restore(snap)
        note = ("물리 위반으로 롤백" if hard
                else f"Rwp 악화({r_before['Rwp']:.3f}→{r_after['Rwp']:.3f})로 롤백")
        return StepResult(False, names, snap, after, r_before,
                          state.r_factors(len(names)),
                          esd=esd,
                          corr=corr.tolist() if corr is not None else [],
                          checks=checks, rolled_back=True, note=note,
                          nfev=calls["n"])
    return StepResult(True, names, snap, after, r_before, r_after,
                      esd=esd,
                      corr=corr.tolist() if corr is not None else [],
                      checks=checks, note="", nfev=calls["n"])


def _esd_and_corr(res, n_obs: int, n_par: int):
    """야코비안에서 공분산 -> 표준편차(esd)와 상관행렬."""
    try:
      with np.errstate(divide='ignore', over='ignore', invalid='ignore'):
          J = res.jac
          _, s, VT = np.linalg.svd(J, full_matrices=False)
          thr = np.finfo(float).eps * max(J.shape) * (s[0] if s.size else 0)
          s = s[s > max(thr, 1e-300)]
          if s.size == 0:
              return {}, None
          VT = VT[: s.size]
          cov = VT.T @ np.diag(1.0 / s ** 2) @ VT
          dof = max(n_obs - n_par, 1)
          cov = cov * (2.0 * res.cost / dof)
          sig = np.sqrt(np.clip(np.diag(cov), 0, None))
          with np.errstate(invalid="ignore", divide="ignore"):
              corr = cov / np.outer(sig, sig)
          corr = np.nan_to_num(corr)
          return {i: float(v) for i, v in enumerate(sig)}, corr
    except Exception:                             # noqa: BLE001
        return {}, None


def lebail_update(state, phase_index: int = 0, damp: float = 1.0) -> float:
    """Le Bail 한 번 갱신.

    구조 모델 없이 강도를 데이터에서 직접 뽑는다. 각 데이터점의 관측 순강도를
    그 점에 기여하는 반사들의 계산 기여도 비율로 나눠 갖고, 반사별 합을
    새 |F|^2 배율로 삼는다. 겹친 반사는 계산비로만 나뉘므로(Le Bail의 한계)
    분리된 정보가 아니라는 점은 결과 해석에서 감안해야 한다.

    반환값: 갱신 전후 배율의 최대 상대변화 (수렴 판정용).
    """
    import numpy as np

    from .pattern import (chebyshev_background, march_dollase, pseudo_voigt,
                          _md_cos2_cached)
    from .structure import structure_factors

    pm = state.models[phase_index]
    ph, pp, refl = pm.phase, pm.profile, pm.refl
    tth = state.two_theta
    if refl is None or len(refl) == 0:
        return 0.0
    if pm.fmul is None:
        pm.fmul = np.ones(len(refl))

    bkg = chebyshev_background(tth, state.bkg_coef)
    ytot = np.clip(state.ycalc() - bkg, 1e-9, None)   # 모든 상의 기여 합
    yobs_net = np.clip(state.yobs - bkg, 0.0, None)

    cell = ph.cell()
    inv_d2 = np.array([cell.calculate_1_d2(list(h)) for h in refl.hkl])
    ok = inv_d2 > 0
    d = 1.0 / np.sqrt(np.where(ok, inv_d2, 1.0))
    stol = 1.0 / (2.0 * d)
    f2 = structure_factors(ph, refl, stol) * pm.fmul
    po = march_dollase(pp.md, _md_cos2_cached(pm, pp.md_hkl))

    num = np.zeros(len(refl))
    den = np.zeros(len(refl))
    for lam, wgt in state.beam.lines():
        s = stol * lam
        good = ok & (s < 0.9995)
        th = np.arcsin(np.clip(s, 0, 0.9995))
        tt0 = (np.degrees(2.0 * th) + state.sample.zero
               + state.sample.displacement * np.cos(th)
               + state.sample.transparency * np.sin(2.0 * th))
        lp = (1.0 + np.cos(2.0 * th) ** 2) / \
             (np.sin(th) ** 2 * np.cos(th) + 1e-12)
        tanth = np.tan(th)
        fwhm = np.sqrt(np.clip(pp.u * tanth ** 2 + pp.v * tanth + pp.w,
                               1e-6, None))
        eta = np.clip(pp.eta0 + pp.eta1 * tt0, 0.0, 1.0)
        inten = pm.scale * wgt * refl.mult * f2 * lp * po
        for i in np.where(good)[0]:
            m = np.abs(tth - tt0[i]) < 12.0 * fwhm[i]
            if not m.any():
                continue
            contrib = inten[i] * pseudo_voigt(tth[m] - tt0[i], fwhm[i],
                                              float(eta[i]))
            num[i] += float(np.sum(yobs_net[m] * contrib / ytot[m]))
            den[i] += float(np.sum(contrib))

    upd = np.where(den > 1e-12, num / np.maximum(den, 1e-12), 1.0)
    upd = np.clip(upd, 0.02, 50.0)
    if damp < 1.0:
        upd = 1.0 + damp * (upd - 1.0)
    pm.fmul = np.clip(pm.fmul * upd, 1e-6, 1e6)
    state._ycache = None
    return float(np.max(np.abs(upd - 1.0)))
