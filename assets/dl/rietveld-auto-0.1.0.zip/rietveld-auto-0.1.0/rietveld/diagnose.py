"""진단 스킬 — "왜 안 맞는가"를 기계가 답하게 만든 절차 모음.

사람이 손으로 하던 배제 추론을 함수로 굳혀 둔 것이다. 모든 함수는
JSON 으로 직렬화 가능한 dict 를 돌려주므로, 어떤 AI 에이전트든
`python -m rietveld.cli <명령> --json` 으로 호출해 같은 결론을 재현·검증할 수 있다.

설계 규칙
---------
- 각 함수는 **판정이 아니라 증거**를 돌려준다. 결론 문장은 `verdict` 에 넣되
  반드시 그 근거 숫자를 같이 싣는다.
- 물질 보편의 임의 컷오프를 쓰지 않는다. 문턱값은 전부 인자로 노출한다.
- 음성 판정("아니다")은 **무엇을 확인했는지 범위를 명시**해서 돌려준다.
"""
from __future__ import annotations

import math

import numpy as np

LAM_CU = 1.540598


# ---------------------------------------------------------------------------
# 1. 구조인자 자체 검산
# ---------------------------------------------------------------------------
def verify_structure_factors(state, phase_index: int = 0, n: int = 12) -> dict:
    """엔진의 |F|² 를 독립 경로(반복문 직접 계산)로 다시 계산해 대조한다.

    엔진 버그를 배제하지 못하면 그 뒤 모든 결론이 무의미하다. 가장 먼저 돌린다.
    """
    import gemmi

    from .structure import expand_sites, structure_factors
    pm = state.models[phase_index]
    ph, refl = pm.phase, pm.refl
    cell = ph.cell()
    inv_d2 = np.array([cell.calculate_1_d2(list(h)) for h in refl.hkl])
    ok = inv_d2 > 0
    d = 1.0 / np.sqrt(np.where(ok, inv_d2, 1.0))
    stol = 1.0 / (2.0 * d)
    eng = structure_factors(ph, refl, stol)
    exp = expand_sites(ph)
    rows, worst = [], 0.0
    for i in np.argsort(-d)[:n]:
        if not ok[i]:
            continue
        s2 = float(stol[i] ** 2)
        F = 0j
        for site, pos in exp:
            f = gemmi.Element(site.element).it92.calculate_sf(s2) * \
                math.exp(-site.biso * s2)
            F += site.occ * f * sum(
                np.exp(2j * np.pi * float(refl.hkl[i] @ p)) for p in pos)
        ref = abs(F) ** 2
        ratio = float(eng[i] / ref) if ref > 1e-12 else float("nan")
        worst = max(worst, abs(ratio - 1.0)) if ref > 1e-12 else worst
        rows.append({"hkl": [int(v) for v in refl.hkl[i]],
                     "d": round(float(d[i]), 4),
                     "engine": round(float(eng[i]), 3),
                     "independent": round(ref, 3),
                     "ratio": round(ratio, 6)})
    return {"skill": "verify_structure_factors",
            "phase": ph.name, "n_checked": len(rows),
            "max_deviation": round(worst, 8), "rows": rows,
            "verdict": ("구조인자 계산은 일치한다 (최대 편차 %.2e). "
                        "엔진 버그는 배제된다." % worst) if worst < 1e-6 else
                       ("구조인자가 독립 계산과 다르다 (최대 편차 %.2e). "
                        "이 상태의 정련 결과는 신뢰할 수 없다." % worst)}


# ---------------------------------------------------------------------------
# 2. 기하 모델 선택 (영점 / 시료변위 / 투과)
# ---------------------------------------------------------------------------
def geometry_model(two_theta_obs, hkl_n, lam: float = LAM_CU,
                   system: str = "cubic") -> dict:
    """관측 피크 위치에서 격자 + 기하 보정 모델을 고른다.

    영점(상수), 시료변위(∝cosθ), 투과(∝sin2θ)는 서로 얽힌다. 어느 항이
    실제로 필요한지는 '넣었을 때 잔차가 줄어드는가'로만 판정할 수 있다.
    """
    from scipy.optimize import least_squares
    t = np.asarray(two_theta_obs, float)
    n = np.asarray(hkl_n, float)

    def calc(a, corr):
        d = a / np.sqrt(n)
        s = np.clip(lam / (2.0 * d), 0, 0.9999)
        th = np.arcsin(s)
        return np.degrees(2.0 * th) + corr(th)

    models = {
        "a only": (lambda p: calc(p[0], lambda th: 0.0), [t.mean() * 0 + 5.7]),
        "a + zero": (lambda p: calc(p[0], lambda th: p[1]), [5.7, 0.0]),
        "a + disp*cos": (lambda p: calc(p[0], lambda th: p[1] * np.cos(th)),
                         [5.7, 0.0]),
        "a + zero + disp*cos":
            (lambda p: calc(p[0], lambda th: p[1] + p[2] * np.cos(th)),
             [5.7, 0.0, 0.0]),
        "a + zero + disp*cos + transp*sin2":
            (lambda p: calc(p[0], lambda th: p[1] + p[2] * np.cos(th)
                            + p[3] * np.sin(2 * th)), [5.7, 0, 0, 0]),
    }
    out = {}
    for name, (f, p0) in models.items():
        p0 = list(p0)
        p0[0] = float(np.median(np.sqrt(n) * lam /
                                (2 * np.sin(np.radians(t / 2)))))
        r = least_squares(lambda p: f(p) - t, p0)
        out[name] = {"rms_deg": round(float(np.sqrt(np.mean(r.fun ** 2))), 5),
                     "max_deg": round(float(np.max(np.abs(r.fun))), 5),
                     "a": round(float(r.x[0]), 5),
                     "terms": [round(float(v), 5) for v in r.x[1:]]}
    best = min(out, key=lambda k: out[k]["rms_deg"])
    simple = "a + zero"
    gain = out[simple]["rms_deg"] / max(out[best]["rms_deg"], 1e-9)
    chosen = best if gain > 1.2 else simple
    return {"skill": "geometry_model", "system": system,
            "n_peaks": int(len(t)), "models": out, "best_rms": best,
            "recommended": chosen,
            "verdict": (f"'{chosen}' 로 충분하다 (rms {out[chosen]['rms_deg']}°). "
                        f"더 복잡한 모델을 넣어도 rms 가 "
                        f"{out[best]['rms_deg']}° 로 {(1-1/gain)*100:.0f}% 밖에 "
                        f"줄지 않으므로 추가 항은 정당화되지 않는다.")}


def strip_ka2(two_theta, intensity, lam1: float, lam2: float,
              tol: float = 0.035, max_ratio: float = 0.75):
    """Kα2 동반 피크를 골라낸다.

    Kα2 는 Kα1 의 고각 쪽에 2·tanθ·Δλ/λ 만큼 떨어져, 세기는 절반쯤으로 나온다.
    이걸 걸러내지 않고 지수화하면 위성이 격자상수를 오염시킨다.
    """
    t = np.asarray(two_theta, float)
    y = np.asarray(intensity, float)
    is_ka2 = np.zeros(len(t), bool)
    for i in range(len(t)):
        for j in range(len(t)):
            if i == j or y[j] <= y[i] or y[i] > max_ratio * y[j]:
                continue
            s1 = math.sin(math.radians(t[j] / 2.0)) * lam2 / lam1
            if s1 >= 1.0:
                continue
            pred = 2.0 * math.degrees(math.asin(s1))
            if abs(t[i] - pred) < tol:
                is_ka2[i] = True
                break
    return ~is_ka2, is_ka2


def index_cubic(two_theta, y, lam: float = LAM_CU, prominence: float = 0.008,
                max_n: int = 50, tol_deg: float = 0.05,
                lam2: float | None = None) -> dict:
    """단순입방 가정으로 자동 지수화한다.

    (a, 영점)을 함께 맞추고, 허용 |Δ2θ| 안에 드는 것만 지수화된 것으로 센다.
    Kα2 위성은 먼저 걸러낸다.
    """
    from scipy.optimize import least_squares

    from .cod import find_peaks
    from .pattern import SOURCES
    tt = np.asarray(two_theta, float)
    yy = np.asarray(y, float)
    if lam2 is None:
        for v in SOURCES.values():
            if abs(v["ka1"] - lam) < 1e-4:
                lam2 = v["ka2"]
        lam2 = lam2 or lam * 1.002485
    pk = find_peaks(tt, yy, prominence_frac=prominence)
    if len(pk) < 4:
        return {"skill": "index_cubic", "error": "피크가 너무 적다",
                "n_peaks": int(len(pk))}
    inten = np.array([yy[np.argmin(np.abs(tt - t))] for t in pk])
    keep, ka2 = strip_ka2(pk, inten, lam, lam2)
    t1, i1 = pk[keep], inten[keep]
    allowed = sorted({h * h + k * k + l * l
                      for h in range(10) for k in range(10) for l in range(10)
                      if 0 < h * h + k * k + l * l <= max_n})

    def assign(a, zero):
        out = []
        for t in t1:
            best, bn = 1e9, None
            for n in allowed:
                d = a / math.sqrt(n)
                s = lam / (2.0 * d)
                if s >= 1.0:
                    continue
                tc = math.degrees(2.0 * math.asin(s)) + zero
                if abs(tc - t) < best:
                    best, bn = abs(tc - t), n
            out.append((bn, best))
        return out

    # (a, 영점) 을 격자 탐색으로 전역 검색한다. 국소 최적화만 쓰면
    # 위성 피크에 끌려 엉뚱한 a 로 수렴한다.
    dmax = float(np.max(t1)) * 0 + 1.0
    best = None
    for zero in np.linspace(-0.5, 0.5, 201):
        sarg = np.sin(np.radians((t1 - zero) / 2.0))
        if np.any(sarg <= 0):
            continue
        dd = lam / (2.0 * sarg)
        Q = 1.0 / dd ** 2
        for n1 in (1, 2, 3, 4):
            inv_a2 = Q[int(np.argmin(Q))] / n1      # 최대 d 피크를 n1 로
            if inv_a2 <= 0:
                continue
            ns = Q / inv_a2
            rn = np.round(ns).astype(int)
            good = np.array([(r in allowed) and abs(v - r) < 0.04 * max(1.0, v / 6.0)
                             for v, r in zip(ns, rn)])
            hit = int(good.sum())
            if hit < 4:
                continue
            a_try = 1.0 / math.sqrt(inv_a2)

            def res(p, ns_=rn[good], tt_=t1[good]):
                o = []
                for t, n in zip(tt_, ns_):
                    ss = lam / (2.0 * (p[0] / math.sqrt(n)))
                    o.append(math.degrees(2.0 * math.asin(min(ss, 0.9999)))
                             + p[1] - t)
                return np.array(o)
            try:
                r = least_squares(res, [a_try, zero])
            except Exception:                           # noqa: BLE001
                continue
            aa, zz = float(r.x[0]), float(r.x[1])
            asg2 = assign(aa, zz)
            hit2 = sum(1 for _, dv in asg2 if dv < tol_deg)
            acc = [dv for _, dv in asg2 if dv < tol_deg]
            rms2 = float(np.sqrt(np.mean(acc))) if acc else 9.0
            rms2 = float(np.sqrt(np.mean(np.square(acc)))) if acc else 9.0
            if best is None or (hit2, -rms2) > (best[0], -best[1]):
                best = (hit2, rms2, aa, zz, asg2)
    if best is None:
        return {"skill": "index_cubic", "error": "입방 해를 찾지 못했다",
                "n_kalpha1": int(len(t1))}
    hit, rms, a, zero, asg = best
    rows, idx_t, idx_n, extra = [], [], [], []
    for t, i, (n, dv) in zip(t1, i1, asg):
        ok = dv < tol_deg
        row = {"two_theta": round(float(t), 3),
               "d": round(lam / (2 * math.sin(math.radians(t / 2))), 4),
               "intensity": float(i), "n": n, "delta_deg": round(float(dv), 4),
               "indexed": bool(ok)}
        rows.append(row)
        (idx_t.append(float(t)), idx_n.append(n)) if ok else extra.append(row)
    missing = [v for v in allowed[:15] if v not in idx_n]
    return {"skill": "index_cubic", "a_estimate": round(a, 5),
            "zero_estimate": round(zero, 5),
            "rms_deg": round(rms, 5), "tol_deg": tol_deg,
            "n_peaks_found": int(len(pk)),
            "n_ka2_removed": int(ka2.sum()),
            "n_kalpha1": int(len(t1)), "n_indexed": len(idx_t),
            "missing_indices": missing,
            "peaks": rows, "unindexed": extra,
            "indexed_two_theta": idx_t, "indexed_n": idx_n,
            "verdict": (f"Kα1 피크 {len(t1)}개 중 {len(idx_t)}개가 단순입방 "
                        f"a≈{a:.5f} Å, 영점 {zero:+.4f}° 로 지수화된다 "
                        f"(rms {rms:.4f}°). 설명 안 되는 피크 {len(extra)}개. "
                        + ("가능한 지수가 빠짐없이 나타나고 소광이 없으므로 "
                           "이 범위에서 직방·정방 분리 증거는 없다."
                           if not extra and not missing else
                           "설명 안 되는 피크가 있다 — 2차상 또는 격자 왜곡을 "
                           "의심한다."))}


# ---------------------------------------------------------------------------
# 3. 반사별 강도 감사
# ---------------------------------------------------------------------------
def intensity_audit(state, phase_index: int = 0, window: float = 0.40,
                    trend_split: tuple = (40.0, 55.0)) -> dict:
    """반사별 관측/계산 적분강도 비를 낸다.

    - 각도 추세가 있으면  → B_iso · 흡수 · 스케일 계통 문제
    - 특정 반사만 튀면    → 겹친 2차상 반사 또는 배향
    이 둘을 구분하는 것이 진단의 핵심 분기점이다.
    """
    from .pattern import chebyshev_background
    tt = state.two_theta
    yo = state.yobs
    yc = state.ycalc()
    bkg = chebyshev_background(tt, state.bkg_coef)
    rows, seen = [], set()
    for p in sorted(state.peaks(), key=lambda p: p["two_theta"]):
        t0 = p["two_theta"]
        key = round(t0, 1)
        if key in seen:
            continue
        m = (tt > t0 - window) & (tt < t0 + window)
        if m.sum() < 5:
            continue
        io = float(np.trapezoid(yo[m] - bkg[m], tt[m]))
        ic = float(np.trapezoid(yc[m] - bkg[m], tt[m]))
        if ic <= 0:
            continue
        seen.add(key)
        rows.append({"hkl": p["hkl"], "two_theta": round(t0, 3),
                     "I_obs": round(io, 1), "I_calc": round(ic, 1),
                     "ratio": round(io / ic, 3),
                     "excess": round(io - ic, 1)})
    if not rows:
        return {"skill": "intensity_audit", "error": "적분할 반사가 없다"}
    r = np.array([x["ratio"] for x in rows])
    t = np.array([x["two_theta"] for x in rows])
    lo_m, hi_m = t < trend_split[0], t > trend_split[1]
    med = float(np.median(r))
    lo = float(np.median(r[lo_m])) if lo_m.any() else float("nan")
    hi = float(np.median(r[hi_m])) if hi_m.any() else float("nan")
    ex = np.array([abs(x["excess"]) for x in rows])
    k = int(np.argmax(ex))
    second = float(np.sort(ex)[-2]) if len(ex) > 1 else 0.0
    dom = rows[k]
    trend = abs(lo - hi) if np.isfinite(lo) and np.isfinite(hi) else 0.0
    dominant_significant = bool(second > 0 and ex[k] > 4 * second)
    if trend > 0.15:
        verdict = (f"obs/calc 에 각도 추세가 있다 (저각 {lo:.2f} → 고각 {hi:.2f}). "
                   f"B_iso · 흡수 · 미세흡수 같은 계통 항을 먼저 의심한다.")
    elif dominant_significant:
        verdict = (f"각도 추세는 없고(저각 {lo:.2f}, 고각 {hi:.2f}, 중앙값 {med:.2f}) "
                   f"{dom['hkl']} 하나만 초과분 {dom['excess']:.0f} 로 "
                   f"2위({second:.0f})의 {ex[k]/max(second,1e-9):.0f}배다. "
                   f"계통 항이 아니라 그 위치에 겹친 무언가를 찾아야 한다.")
    else:
        verdict = (f"뚜렷한 각도 추세도, 단일 이상 반사도 없다 "
                   f"(중앙값 {med:.2f}, 저각 {lo:.2f}, 고각 {hi:.2f}).")
    return {"skill": "intensity_audit", "phase": state.models[phase_index].phase.name,
            "median_ratio": round(med, 3),
            "low_angle_median": round(lo, 3), "high_angle_median": round(hi, 3),
            "angular_trend": round(trend, 3),
            "dominant_outlier": dom,
            "dominant_significant": dominant_significant,
            "excess_ratio_to_second": round(float(ex[k] / max(second, 1e-9)), 2),
            "rows": rows, "verdict": verdict}


# ---------------------------------------------------------------------------
# 4. 배향 검정
# ---------------------------------------------------------------------------
def texture_test(state, phase_index: int = 0,
                 axes=((1, 0, 0), (1, 1, 0), (1, 1, 1), (0, 0, 1))) -> dict:
    """어떤 March-Dollase 축이 obs/calc 편차를 설명하는지 본다.

    배향이면 같은 축 계열의 반사가 **함께** 커지거나 작아져야 한다.
    (100)은 그대로인데 (200)만 크다면 배향이 아니다.
    """
    from .pattern import _md_cos2
    audit = intensity_audit(state, phase_index)
    if "rows" not in audit:
        return {"skill": "texture_test", "error": audit.get("error")}
    pm = state.models[phase_index]
    hkl = np.array([r["hkl"] for r in audit["rows"]])
    ratio = np.array([r["ratio"] for r in audit["rows"]])
    w = np.array([r["I_calc"] for r in audit["rows"]])
    out = []
    for ax in axes:
        c2 = _md_cos2(pm.phase, hkl, ax)
        # 배향이면 ratio 가 cos^2(alpha) 와 단조 관계여야 한다
        if np.ptp(c2) < 1e-6:
            continue
        cc = float(np.corrcoef(c2, ratio)[0, 1])
        out.append({"axis": list(ax), "corr": round(cc, 3),
                    "cos2_range": [round(float(c2.min()), 3),
                                   round(float(c2.max()), 3)]})
    out.sort(key=lambda x: -abs(x["corr"]))
    best = out[0] if out else None
    ok = best is not None and abs(best["corr"]) > 0.6
    return {"skill": "texture_test", "axes": out,
            "verdict": (f"축 {best['axis']} 와 상관 {best['corr']:+.2f} — "
                        f"우선방위로 설명될 여지가 있다. March-Dollase 를 켜고 "
                        f"다시 보라." if ok else
                        f"어떤 축도 obs/calc 편차를 설명하지 못한다 "
                        f"(최대 |상관| {abs(best['corr']):.2f}, 검사한 축 "
                        f"{[a['axis'] for a in out]}). 우선방위는 배제된다."
                        if best else "검정할 축이 없다")}


# ---------------------------------------------------------------------------
# 5. 불순물 상 선별
# ---------------------------------------------------------------------------
def impurity_screen(state, formulas, target_two_theta: float,
                    tol: float = 0.35, veto_frac: float = 0.30,
                    max_per_formula: int = 2) -> dict:
    """설명 안 되는 위치에 강선을 갖는 COD 상을 찾되, **거부 조건**을 함께 본다.

    핵심은 '그 위치에 선이 있는가'가 아니라
    '그 상의 다른 강선이 관측에 실제로 있는가' 이다. 후자가 없으면 배제한다.
    """
    from scipy.ndimage import minimum_filter1d, uniform_filter1d

    from .cod import fetch_cif, search
    from .pattern import Beam, PhaseModel
    from .refine import RefinementState
    from .structure import generate_reflections, read_cif
    tt = state.two_theta
    yo = state.yobs
    base = uniform_filter1d(minimum_filter1d(yo, 151), 151)
    net = yo - base
    thr = 0.02 * float(net.max())
    zero = state.sample.zero
    rows = []
    for f in formulas:
        try:
            cands = [c for c in search(f) if c["ratio_ok"]][:max_per_formula]
        except Exception as exc:                       # noqa: BLE001
            rows.append({"formula": f, "error": str(exc)})
            continue
        for c in cands:
            try:
                ph = read_cif(fetch_cif(c["cod_id"]), is_text=True,
                              source=f"COD {c['cod_id']}")
                ph.name = f
                pm = PhaseModel(phase=ph)
                pm.refl = generate_reflections(ph, 0.95)
                st2 = RefinementState(tt, yo, [pm], Beam(state.beam.anode,
                                                         use_ka2=False))
                pk = sorted(st2.peaks(), key=lambda p: -p["intensity"])
                if not pk:
                    continue
                imax = pk[0]["intensity"]
                at_target = [p for p in pk
                             if abs(p["two_theta"] + zero - target_two_theta) < tol
                             and p["intensity"] > 0.25 * imax]
                absent = []
                for p in pk:
                    if p["intensity"] < veto_frac * imax:
                        continue
                    t = p["two_theta"] + zero
                    if t < tt[0] or t > tt[-1]:
                        continue
                    j = int(np.argmin(np.abs(tt - t)))
                    if net[j] < thr:
                        absent.append({"hkl": p["hkl"],
                                       "two_theta": round(t, 2),
                                       "rel": round(p["intensity"] / imax, 2),
                                       "observed_net": round(float(net[j]), 0)})
                rows.append({"formula": f, "cod_id": c["cod_id"],
                             "spacegroup": c["spacegroup"],
                             "line_at_target": bool(at_target),
                             "target_hkl": at_target[0]["hkl"] if at_target else None,
                             "absent_strong_lines": absent,
                             "verdict": ("후보" if at_target and not absent
                                         else "배제: 목표 위치에 강선 없음"
                                         if not at_target else
                                         f"배제: 강선 {len(absent)}개가 관측에 없음")})
            except Exception as exc:                   # noqa: BLE001
                rows.append({"formula": f, "cod_id": c.get("cod_id"),
                             "error": str(exc)})
    survivors = [r for r in rows if r.get("verdict") == "후보"]
    return {"skill": "impurity_screen", "target_two_theta": target_two_theta,
            "screened": rows, "survivors": survivors,
            "verdict": (f"{len(survivors)}개 후보가 남았다: "
                        f"{[s['formula'] for s in survivors]}" if survivors else
                        f"검사한 {len(rows)}개 상이 모두 배제됐다. "
                        f"동반 반사가 전혀 없으므로, 남은 강도는 **다른 반사가 "
                        f"주상과 겹치는 상**(유사입방 격자가 거의 같은 변종)에 "
                        f"속할 가능성이 높다. Le Bail 을 쓰라.")}


# ---------------------------------------------------------------------------
# 6. 결정립 크기 / 미세변형
# ---------------------------------------------------------------------------
def size_strain(state, phase_index: int = 0, K: float = 0.9) -> dict:
    """TCH 의 X(변형)·Y(크기)에서 결정립 크기와 미세변형을 낸다.

    tch=False 면 U,V,W 만으로는 둘을 분리할 수 없으므로 그 사실을 돌려준다.
    """
    pm = state.models[phase_index]
    p = pm.profile
    lam = state.beam.lines()[0][0]
    if not p.tch:
        return {"skill": "size_strain", "available": False,
                "verdict": ("단순 pseudo-Voigt 모드에서는 결정립 크기와 "
                            "미세변형을 분리할 수 없다. profile.tch=True 로 "
                            "바꾸고 X(변형)·Y(크기)를 정련하라.")}
    beta_L = math.radians(p.y)            # Y/cos(th) 의 cos 를 뺀 적분폭 기여
    size = (K * lam / beta_L / 10.0) if beta_L > 1e-9 else float("inf")  # nm
    strain = math.radians(p.x) / 4.0      # X*tan(th) -> eps = X/4 (rad)
    return {"skill": "size_strain", "available": True,
            "X": p.x, "Y": p.y,
            "crystallite_size_nm": (round(size, 1) if math.isfinite(size)
                                    else None),
            "microstrain": round(strain, 6),
            "verdict": ((f"Y={p.y:.4f}° → 결정립 크기 ≈ {size:.0f} nm. "
                         if math.isfinite(size) else "Y≈0 → 크기 넓힘 없음. ")
                        + (f"X={p.x:.4f}° → 미세변형 ≈ {strain*100:.3f} %."
                           if p.x > 1e-6 else
                           "X≈0 → 미세변형은 검출되지 않는다(크기 넓힘 지배).")
                        + " 기기 프로파일을 표준시료로 빼지 않았다면 이 값은 "
                          "상한이다.")}


# ---------------------------------------------------------------------------
# 전체 절차
# ---------------------------------------------------------------------------
def eliminate(state, phase_index: int = 0, impurity_formulas=None) -> dict:
    """배제 추론 전체를 순서대로 돌린다. 이 순서에는 이유가 있다.

    1) 엔진 자체를 먼저 배제하지 않으면 뒤 결론이 전부 무의미하다.
    2) 각도 추세 유무가 '계통 항' 과 '겹친 상' 을 가르는 분기점이다.
    3) 배향은 같은 축 계열이 함께 움직이는지로 판정된다.
    4) 불순물은 '그 위치에 선이 있는가' 가 아니라
       '다른 강선이 관측에 있는가' 로 배제한다.
    """
    out = {"skill": "eliminate", "steps": []}
    sf = verify_structure_factors(state, phase_index)
    out["steps"].append(sf)
    if sf["max_deviation"] > 1e-6:
        out["conclusion"] = "엔진 구조인자가 틀렸다. 여기서 멈추고 고쳐야 한다."
        return out
    au = intensity_audit(state, phase_index)
    out["steps"].append(au)
    tx = texture_test(state, phase_index)
    out["steps"].append(tx)
    ss = size_strain(state, phase_index)
    out["steps"].append(ss)
    dom = au.get("dominant_outlier")
    if impurity_formulas and dom:
        out["steps"].append(impurity_screen(state, impurity_formulas,
                                            dom["two_theta"]))
    trend = au.get("angular_trend", 0.0)
    if trend > 0.15:
        out["conclusion"] = ("계통 항 문제로 보인다 (obs/calc 각도 추세 "
                             f"{trend:.2f}). B_iso · 흡수를 먼저 보라.")
    elif dom and au.get("dominant_significant"):
        out["conclusion"] = (
            f"{dom['hkl']} (2θ={dom['two_theta']}°) 하나에 초과강도 "
            f"{dom['excess']:.0f} 가 몰려 있고, 각도 추세도 배향도 아니다. "
            f"그 위치에 겹친 상을 찾아라. 동반 반사가 어디에도 없으면 "
            f"주상과 격자가 거의 같은 변종이므로 Le Bail 로 강도를 뽑아라.")
    else:
        out["conclusion"] = (
            "구조인자·계통 항·배향 어느 쪽에서도 뚜렷한 이상이 없다 "
            f"(obs/calc 중앙값 {au.get('median_ratio')}, 각도 추세 {trend:.2f}, "
            f"최대 초과분/2위 = {au.get('excess_ratio_to_second')}). "
            "남은 잔차는 피크 모양(프로파일 함수) 쪽을 보라.")
    return out
