"""COD (Crystallography Open Database) 검색과 후보 순위.

검색 엔드포인트 확인 (2026-09-30):
  https://www.crystallography.net/cod/result?format=json&el1=V&el2=O&nel=2
  -> 200, 항목별 file/sg/sgNumber/a,b,c,alpha,beta,gamma/vol/celltemp/formula
주의: formula= 파라미터는 COD 내부 표기('- O2 V -')와 맞추기 어렵다.
      원소+개수 질의로 받아온 뒤 조성 필터는 이쪽에서 건다.
"""
from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request

BASE = "https://www.crystallography.net/cod"
_UA = {"User-Agent": "rietveld-auto/0.1 (research use)"}


def _get(url: str, timeout: int = 40) -> bytes:
    req = urllib.request.Request(url, headers=_UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def parse_formula(text: str) -> dict[str, float]:
    """'VO2', 'V O2', 'La0.7Sr0.3MnO3' -> {원소: 개수}"""
    out: dict[str, float] = {}
    for el, num in re.findall(r"([A-Z][a-z]?)\s*([0-9]*\.?[0-9]*)", text):
        if not el:
            continue
        out[el] = out.get(el, 0.0) + (float(num) if num else 1.0)
    return out


def search(formula: str, *, strict_nel: bool = True, limit: int = 60) -> list[dict]:
    """조성 문자열로 COD를 검색한다."""
    comp = parse_formula(formula)
    els = list(comp)
    if not els:
        return []
    q = {f"el{i+1}": e for i, e in enumerate(els[:8])}
    q["format"] = "json"
    if strict_nel:
        q["nel"] = str(len(els))
    raw = _get(f"{BASE}/result?" + urllib.parse.urlencode(q))
    try:
        rows = json.loads(raw)
    except json.JSONDecodeError:
        return []
    out = []
    for r in rows:
        f = r.get("formula") or ""
        got = parse_formula(f.replace("-", " "))
        if strict_nel and set(got) != set(els):
            continue
        out.append({
            "cod_id": r.get("file"), "formula": f.strip(" -"),
            "spacegroup": r.get("sg"), "sg_number": r.get("sgNumber"),
            "a": _f(r.get("a")), "b": _f(r.get("b")), "c": _f(r.get("c")),
            "alpha": _f(r.get("alpha")) or 90.0,
            "beta": _f(r.get("beta")) or 90.0,
            "gamma": _f(r.get("gamma")) or 90.0,
            "volume": _f(r.get("vol")), "temperature": _f(r.get("celltemp")),
            "mineral": r.get("mineral"), "commonname": r.get("commonname"),
            "ratio_ok": _ratio_match(comp, got),
            "url": f"{BASE}/{r.get('file')}.html",
            "cif_url": f"{BASE}/{r.get('file')}.cif",
        })
    out.sort(key=lambda x: (not x["ratio_ok"], x["cod_id"] or ""))
    return out[:limit]


def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _ratio_match(want: dict, got: dict, tol: float = 0.04) -> bool:
    """조성비가 맞는지 (VO2 검색에 V4O7이 섞여 나오는 것을 걸러낸다)."""
    if set(want) != set(got) or not got:
        return False
    k = next(iter(want))
    if got.get(k, 0) == 0:
        return False
    s = want[k] / got[k]
    return all(abs(want[e] - s * got[e]) <= tol * want[e] for e in want)


def fetch_cif(cod_id: str | int) -> str:
    return _get(f"{BASE}/{cod_id}.cif").decode("utf-8", "replace")


def rank_by_pattern(candidates: list[dict], two_theta, yobs, beam,
                    d_min_frac: float = 0.98, top: int = 8) -> list[dict]:
    """각 후보 CIF로 패턴을 계산해 실측과 비교, 순위를 매긴다.

    점수는 '관측 주요 피크가 계산 피크 위치와 얼마나 맞는가'로만 낸다.
    강도는 배향·미세구조에 크게 흔들리므로 위치를 우선한다.
    """
    import numpy as np

    from .pattern import PhaseModel, Sample, calc_pattern
    from .refine import RefinementState
    from .structure import read_cif

    obs_pk = find_peaks(two_theta, yobs)
    out = []
    for cand in candidates[:top]:
        try:
            ph = read_cif(fetch_cif(cand["cod_id"]), is_text=True,
                          source=f"COD {cand['cod_id']}")
            pm = PhaseModel(phase=ph)
            st = RefinementState(two_theta, yobs, [pm], beam)
            pk = [p for p in st.peaks()]
            pk.sort(key=lambda p: -p["intensity"])
            calc_tt = np.array([p["two_theta"] for p in pk[:40]])
            if calc_tt.size == 0 or obs_pk.size == 0:
                continue
            dev = np.array([np.min(np.abs(calc_tt - t)) for t in obs_pk])
            matched = float(np.mean(dev < 0.25))
            out.append({**cand, "match_frac": matched,
                        "mean_dev_deg": float(np.mean(dev)),
                        "n_obs_peaks": int(obs_pk.size)})
        except Exception as exc:                     # noqa: BLE001
            out.append({**cand, "error": str(exc)})
    out.sort(key=lambda x: (-x.get("match_frac", -1),
                            x.get("mean_dev_deg", 99)))
    return out


def find_peaks(two_theta, y, prominence_frac: float = 0.03, width: int = 3):
    """배경을 뺀 뒤 뚜렷한 관측 피크 위치만 뽑는다."""
    import numpy as np
    from scipy.ndimage import minimum_filter1d, uniform_filter1d
    y = np.asarray(y, float)
    bkg = uniform_filter1d(minimum_filter1d(y, 101), 101)
    z = y - bkg
    thr = prominence_frac * np.max(z)
    idx = []
    for i in range(width, len(z) - width):
        if z[i] >= thr and z[i] == np.max(z[i - width:i + width + 1]):
            if not idx or i - idx[-1] > width:
                idx.append(i)
    return np.asarray(two_theta, float)[idx]


PNMA_TEMPLATE = """data_pnma_perovskite
_symmetry_space_group_name_H-M   'P n m a'
_cell_length_a   {a:.5f}
_cell_length_b   {b:.5f}
_cell_length_c   {c:.5f}
_cell_angle_alpha  90
_cell_angle_beta   90
_cell_angle_gamma  90
loop_
 _atom_site_label
 _atom_site_type_symbol
 _atom_site_fract_x
 _atom_site_fract_y
 _atom_site_fract_z
 _atom_site_occupancy
 _atom_site_U_iso_or_equiv
 A1  {A}  0.04800 0.25000 -0.00800 1.0 0.038
 B1  {B}  0.00000 0.00000  0.50000 1.0 0.025
 X1  {X}  0.49000 0.25000  0.06000 1.0 0.044
 X2  {X}  0.28000 0.03600  0.72000 1.0 0.044
"""


def pnma_template_cif(A: str, B: str, X: str, a_pc: float,
                      da: float = 1.0, db: float = 1.0,
                      dc: float = 1.0) -> str:
    """GdFeO3형(a⁻b⁺a⁻) 기울어진 ABX3 페로브스카이트 CIF 문자열.

    COD에 해당 직방정 상이 없을 때 시작 모델로 쓴다. 좌표는 **일반 템플릿**이며
    특정 물질의 문헌값이 아니다. 격자는 유사입방 파라미터 a_pc 에서 만든다:
    a ≈ √2·a_pc, b ≈ 2·a_pc, c ≈ √2·a_pc.
    구조를 신뢰할 수 없으므로 보통 Le Bail(`lebail_update`)과 함께 쓴다.
    """
    import math
    return PNMA_TEMPLATE.format(A=A, B=B, X=X,
                                a=math.sqrt(2) * a_pc * da,
                                b=2.0 * a_pc * db,
                                c=math.sqrt(2) * a_pc * dc)
