"""파장, 프로파일 함수, 배경, 패턴 계산.

Cu Kalpha1 단독 / Kalpha1+Kalpha2 이중선을 토글로 고른다.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from .structure import Phase, Reflections, structure_factors

# 특성 X선 파장 (Angstrom). 값 출처: International Tables Vol. C.
SOURCES = {
    "Cu": {"ka1": 1.540598, "ka2": 1.544426, "ratio": 0.5},
    "Co": {"ka1": 1.788996, "ka2": 1.792835, "ratio": 0.5},
    "Mo": {"ka1": 0.709317, "ka2": 0.713607, "ratio": 0.5},
    "Cr": {"ka1": 2.289760, "ka2": 2.293663, "ratio": 0.5},
    "Fe": {"ka1": 1.936042, "ka2": 1.939980, "ratio": 0.5},
}


@dataclass
class Beam:
    """선원 설정. `use_ka2=False` 면 Kalpha1 단독(단색화기 사용 시)."""
    anode: str = "Cu"
    use_ka2: bool = True
    ratio: float | None = None      # None이면 기본 0.5

    def lines(self) -> list[tuple[float, float]]:
        s = SOURCES[self.anode]
        if not self.use_ka2:
            return [(s["ka1"], 1.0)]
        r = s["ratio"] if self.ratio is None else self.ratio
        return [(s["ka1"], 1.0 / (1.0 + r)), (s["ka2"], r / (1.0 + r))]

    @property
    def lam_mean(self) -> float:
        ls = self.lines()
        return sum(l * w for l, w in ls) / sum(w for _, w in ls)


@dataclass
class ProfileParams:
    """피크 모양.

    tch=False (기본): Caglioti FWHM + eta 를 직접 정련하는 단순 pseudo-Voigt.
    tch=True        : Thompson-Cox-Hastings. 가우스 성분과 로렌츠 성분을 따로 두고
                      FWHM 과 eta 를 물리적으로 유도한다. FullProf 의 표준 모드.
        Gamma_G^2 = U tan^2(th) + V tan(th) + W + Z / cos^2(th)
        Gamma_L   = X tan(th) + Y / cos(th)
      X 는 미세변형, Y 는 결정립 크기에 대응하므로 둘을 분리할 수 있다.

    비대칭은 Berar-Baldinozzi 형(FullProf 의 Asy1..Asy4 와 같은 식)이다.
    """
    u: float = 0.02
    v: float = -0.004
    w: float = 0.006
    eta0: float = 0.5           # tch=False 일 때만: eta = eta0 + eta1 * 2theta
    eta1: float = 0.0
    md: float = 1.0             # March-Dollase r (1.0 = 무배향)
    md_hkl: tuple = (0, 0, 1)
    # --- TCH ---
    tch: bool = False
    x: float = 0.0              # 로렌츠 tan(th) 항 (미세변형)
    y: float = 0.0              # 로렌츠 1/cos(th) 항 (결정립 크기)
    z: float = 0.0              # 가우스 1/cos^2(th) 항
    # --- 비대칭 (Berar-Baldinozzi) ---
    asy1: float = 0.0
    asy2: float = 0.0
    asy3: float = 0.0
    asy4: float = 0.0

    def widths(self, tanth, costh):
        """(FWHM, eta) 를 돌려준다. 배열 연산."""
        import numpy as np
        if not self.tch:
            fw = np.sqrt(np.clip(self.u * tanth ** 2 + self.v * tanth
                                 + self.w, 1e-6, None))
            return fw, None
        gg2 = (self.u * tanth ** 2 + self.v * tanth + self.w
               + self.z / np.clip(costh ** 2, 1e-6, None))
        gg = np.sqrt(np.clip(gg2, 1e-8, None))
        gl = np.clip(self.x * tanth + self.y / np.clip(costh, 1e-6, None),
                     0.0, None)
        g = (gg ** 5 + 2.69269 * gg ** 4 * gl + 2.42843 * gg ** 3 * gl ** 2
             + 4.47163 * gg ** 2 * gl ** 3 + 0.07842 * gg * gl ** 4
             + gl ** 5) ** 0.2
        g = np.clip(g, 1e-4, None)
        q = np.clip(gl / g, 0.0, 1.0)
        eta = np.clip(1.36603 * q - 0.47719 * q ** 2 + 0.11116 * q ** 3,
                      0.0, 1.0)
        return g, eta

    def has_asymmetry(self):
        return any(abs(v) > 1e-12 for v in
                   (self.asy1, self.asy2, self.asy3, self.asy4))


@dataclass
class Sample:
    """시료/기기 계통오차."""
    zero: float = 0.0           # 영점 (deg 2theta), 각도 무관 상수
    displacement: float = 0.0   # 시료 변위: Delta(2theta) = disp * cos(theta)
    transparency: float = 0.0   # 시료 투과:  Delta(2theta) = transp * sin(2theta)


@dataclass
class PhaseModel:
    phase: Phase
    scale: float = 1.0
    profile: ProfileParams = field(default_factory=ProfileParams)
    refl: Reflections | None = None
    # Le Bail 용 반사별 강도 배율. None이면 구조 모델의 |F|^2 를 그대로 쓴다.
    # 값이 있으면 |F|^2 * fmul 로 쓰므로, 구조를 모를 때 강도를 자유롭게 둘 수 있다.
    fmul: object = None


def pseudo_voigt(dx: np.ndarray, fwhm: float, eta: float) -> np.ndarray:
    """면적 1로 규격화된 pseudo-Voigt."""
    h = max(fwhm, 1e-4)
    g = math.sqrt(4.0 * math.log(2.0) / math.pi) / h * \
        np.exp(-4.0 * math.log(2.0) * (dx / h) ** 2)
    l = (2.0 / (math.pi * h)) / (1.0 + 4.0 * (dx / h) ** 2)
    return eta * l + (1.0 - eta) * g


def berar_baldinozzi(z: np.ndarray, theta: float, p) -> np.ndarray:
    """Berar-Baldinozzi 비대칭 보정 (FullProf Asy1..Asy4 와 같은 형).

    z = (2theta - 2theta_k) / FWHM.
    저각에서 축발산 때문에 생기는 피크 앞쪽 끌림을 재현한다.
    면적을 크게 바꾸지 않도록 보정 인자는 1 주변에서 움직인다.
    """
    fa = 2.0 * z * np.exp(-z * z)
    fb = 2.0 * (2.0 * z * z - 3.0) * fa
    tt = math.tan(theta)
    t2 = math.tan(2.0 * theta)
    c = 1.0
    if abs(tt) > 1e-9:
        c = c + (p.asy1 * fa + p.asy2 * fb) / tt
    if abs(t2) > 1e-9:
        c = c + (p.asy3 * fa + p.asy4 * fb) / t2
    return np.clip(c, 0.0, None)


def march_dollase(r: float, cos_alpha2: np.ndarray) -> np.ndarray:
    """March-Dollase 우선방위 보정.

    r=1 근처에서 단락(early return)하면 안 된다. least_squares 의 수치 미분
    간격은 약 1.5e-8 이라, 1e-6 단락이 걸리면 r=1 에서 기울기가 **정확히 0** 이
    되어 우선방위가 영원히 정련되지 않는다. 항상 계산한다.
    """
    r = max(float(r), 1e-6)
    return (r * r * cos_alpha2 + (1.0 - cos_alpha2) / r) ** -1.5


def _md_cos2(phase: Phase, hkl: np.ndarray, md_hkl) -> np.ndarray:
    """배향축과 각 반사면 법선 사이 각의 cos^2 (역격자 계량으로 계산)."""
    cell = phase.cell()
    g = np.array(cell.calculate_1_d2(list(md_hkl)))
    out = np.empty(len(hkl))
    for i, h in enumerate(hkl):
        d1 = cell.calculate_1_d2(list(h))
        # 역격자 내적: 0.5*(|h+k|^2 - |h|^2 - |k|^2)
        s = [int(h[j]) + int(md_hkl[j]) for j in range(3)]
        dot = 0.5 * (cell.calculate_1_d2(s) - d1 - g)
        out[i] = 0.0 if d1 <= 0 or g <= 0 else (dot ** 2) / (d1 * g)
    return np.clip(out, 0.0, 1.0)


def _md_cos2_cached(pm, md_hkl):
    """cos^2(alpha)는 hkl과 격자 방향비에만 의존한다. 정련 중 격자 변화는
    0.1% 수준이라 방향 코사인은 사실상 불변 -> 캐시해 재계산을 피한다."""
    key = (tuple(md_hkl), round(pm.phase.b / pm.phase.a, 4),
           round(pm.phase.c / pm.phase.a, 4), round(pm.phase.beta, 2))
    cache = getattr(pm, "_md_cache", None)
    if cache is None or cache[0] != key:
        pm._md_cache = (key, _md_cos2(pm.phase, pm.refl.hkl, md_hkl))
    return pm._md_cache[1]


def chebyshev_background(two_theta: np.ndarray, coef) -> np.ndarray:
    lo, hi = two_theta[0], two_theta[-1]
    x = 2.0 * (two_theta - lo) / (hi - lo) - 1.0
    return np.polynomial.chebyshev.chebval(x, np.asarray(coef, float))


def calc_pattern(two_theta: np.ndarray, models: list[PhaseModel],
                 beam: Beam, sample: Sample, bkg_coef,
                 return_peaks: bool = False):
    """다상 분말 패턴. 반환값 단위는 임의(scale이 흡수)."""
    y = chebyshev_background(two_theta, bkg_coef)
    peaks = []
    for pm in models:
        ph, pp = pm.phase, pm.profile
        refl = pm.refl
        if refl is None or len(refl) == 0:
            continue
        cell = ph.cell()
        inv_d2 = np.array([cell.calculate_1_d2(list(h)) for h in refl.hkl])
        ok = inv_d2 > 0
        inv_d2 = np.where(ok, inv_d2, 1.0)
        d = 1.0 / np.sqrt(inv_d2)
        stol = 1.0 / (2.0 * d)
        f2 = structure_factors(ph, refl, stol)
        if pm.fmul is not None:
            f2 = f2 * pm.fmul
        po = march_dollase(pp.md, _md_cos2_cached(pm, pp.md_hkl))
        for lam, wgt in beam.lines():
            s = stol * lam
            good = ok & (s < 0.9995)
            th = np.arcsin(np.clip(s, 0, 0.9995))
            tt = np.degrees(2.0 * th) + sample.zero \
                + sample.displacement * np.cos(th) \
                + sample.transparency * np.sin(2.0 * th)
            lp = (1.0 + np.cos(2.0 * th) ** 2) / \
                 (np.sin(th) ** 2 * np.cos(th) + 1e-12)
            tanth = np.tan(th)
            fwhm, eta_tch = pp.widths(tanth, np.cos(th))
            eta = eta_tch if eta_tch is not None else \
                np.clip(pp.eta0 + pp.eta1 * tt, 0.0, 1.0)
            inten = pm.scale * wgt * refl.mult * f2 * lp * po
            lo, hi = two_theta[0], two_theta[-1]
            for i in np.where(good)[0]:
                t0, h0 = tt[i], fwhm[i]
                if t0 < lo - 5 * h0 or t0 > hi + 5 * h0:
                    continue
                m = np.abs(two_theta - t0) < 12.0 * h0
                if not m.any():
                    continue
                shape = pseudo_voigt(two_theta[m] - t0, h0, float(eta[i]))
                if pp.has_asymmetry():
                    shape = shape * berar_baldinozzi(
                        (two_theta[m] - t0) / h0, float(th[i]), pp)
                y[m] += inten[i] * shape
                if return_peaks and wgt > 0.5:
                    peaks.append({"phase": ph.name,
                                  "hkl": [int(v) for v in refl.hkl[i]],
                                  "two_theta": float(t0), "d": float(d[i]),
                                  "intensity": float(inten[i])})
    return (y, peaks) if return_peaks else y


def r_factors(yobs: np.ndarray, ycalc: np.ndarray, n_par: int = 0):
    w = 1.0 / np.clip(yobs, 1.0, None)
    diff = yobs - ycalc
    rwp = 100.0 * math.sqrt(np.sum(w * diff ** 2) / np.sum(w * yobs ** 2))
    rp = 100.0 * np.sum(np.abs(diff)) / np.sum(np.abs(yobs))
    n = len(yobs)
    rexp = 100.0 * math.sqrt(max(n - n_par, 1) / np.sum(w * yobs ** 2))
    gof = rwp / rexp if rexp > 0 else float("nan")
    return {"Rwp": rwp, "Rp": rp, "Rexp": rexp,
            "GOF": gof, "chi2": gof ** 2}
