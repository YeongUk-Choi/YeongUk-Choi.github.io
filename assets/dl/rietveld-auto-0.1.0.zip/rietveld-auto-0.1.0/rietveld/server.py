"""로컬 웹 서버: 실시간 정련 화면 + AI 채팅.

의존성을 늘리지 않으려고 표준 라이브러리 http.server + SSE 로 만들었다.
실행:  python -m rietveld.server [--port 8765] [--data pattern.xy]
"""
from __future__ import annotations

import argparse
import json
import mimetypes
import os
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np

from .session import Session

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB = os.path.join(ROOT, "web")
SESSION = Session()


def read_xy(path: str):
    """.xy / .dat / .txt (2theta intensity) 와 .xrdml 를 읽는다."""
    if path.lower().endswith(".xrdml"):
        return _read_xrdml(path)
    tt, y = [], []
    with open(path, "r", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line or line[0] in "#!'*/":
                continue
            parts = line.replace(",", " ").split()
            try:
                a, b = float(parts[0]), float(parts[1])
            except (ValueError, IndexError):
                continue
            tt.append(a)
            y.append(b)
    if len(tt) < 10:
        raise ValueError(f"{path}: 데이터 점이 너무 적습니다 ({len(tt)})")
    return np.array(tt), np.array(y)


def _read_xrdml(path: str):
    import xml.etree.ElementTree as ET
    t = ET.parse(path)
    ns = {"x": t.getroot().tag.split("}")[0].strip("{")}
    pos = t.find(".//x:positions[@axis='2Theta']", ns)
    start = float(pos.find("x:startPosition", ns).text)
    end = float(pos.find("x:endPosition", ns).text)
    counts = [float(v) for v in
              t.find(".//x:counts", ns).text.split()]
    return np.linspace(start, end, len(counts)), np.array(counts)


def _finite(o):
    """JSON으로 나갈 수 없는 Infinity/NaN을 안전한 값으로 바꾼다."""
    if isinstance(o, float):
        if o != o:
            return None
        if o == float("inf"):
            return 1e308
        if o == float("-inf"):
            return -1e308
        return o
    if isinstance(o, dict):
        return {k: _finite(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_finite(v) for v in o]
    if isinstance(o, np.generic):
        return _finite(o.item())
    if isinstance(o, np.ndarray):
        return _finite(o.tolist())
    return o


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):        # 조용히
        pass

    # ---------------- GET ----------------
    def do_GET(self):
        if self.path.startswith("/api/events"):
            return self._sse()
        if self.path.startswith("/api/status"):
            return self._json({"status": SESSION.status(),
                               "plot": SESSION.plot_payload(),
                               "chat": SESSION.chat,
                               "log": SESSION.bus.history[-120:]})
        rel = "index.html" if self.path in ("/", "") else self.path.lstrip("/")
        p = os.path.join(WEB, rel)
        if not os.path.isfile(p):
            return self._send(404, b"not found", "text/plain")
        with open(p, "rb") as f:
            body = f.read()
        ctype = mimetypes.guess_type(p)[0] or "application/octet-stream"
        self._send(200, body, ctype)

    def _sse(self):
        q = SESSION.bus.subscribe()
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        try:
            while True:
                try:
                    ev = q.get(timeout=15)
                    data = json.dumps(_finite(ev), ensure_ascii=False,
                                      default=str)
                    self.wfile.write(f"data: {data}\n\n".encode())
                except Exception:
                    self.wfile.write(b": ping\n\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            SESSION.bus.unsubscribe(q)

    # ---------------- POST ----------------
    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            return self._json({"error": "bad json"}, 400)
        try:
            return self._json(self._route(self.path, body))
        except Exception as exc:                       # noqa: BLE001
            SESSION.log(f"{type(exc).__name__}: {exc}", "error")
            traceback.print_exc()
            return self._json({"error": str(exc)}, 500)

    def _route(self, path, b):
        if path == "/api/beam":
            SESSION.set_beam(b.get("anode", "Cu"), bool(b.get("use_ka2", True)),
                             b.get("ratio"))
            return {"ok": True}
        if path == "/api/load":
            tt, y = read_xy(b["path"])
            SESSION.load_pattern(tt, y, os.path.basename(b["path"]))
            return {"ok": True, "n": len(tt)}
        if path == "/api/search":
            return {"candidates": SESSION.search_cod(b["formula"],
                                                     b.get("rank", True))}
        if path == "/api/phase":
            ph = SESSION.use_phase(cod_id=b.get("cod_id"),
                                   cif_text=b.get("cif"), name=b.get("name"),
                                   add=bool(b.get("add")))
            return {"ok": True, "phase": ph.name}
        if path == "/api/lebail":
            threading.Thread(
                target=SESSION.lebail,
                args=(int(b.get("phase", 0)), int(b.get("cycles", 8)),
                      bool(b.get("refine_cell", True))),
                daemon=True).start()
            return {"ok": True}
        if path == "/api/option":
            # 정련 변수가 아닌 모델 선택지 (배향축, 배경 차수 등)
            st = SESSION.state
            if st is None:
                raise RuntimeError("상이 설정되지 않았습니다.")
            i = int(b.get("phase", 0))
            if "md_hkl" in b:
                st.models[i].profile.md_hkl = tuple(int(v) for v in b["md_hkl"])
                st.models[i]._md_cache = None
                SESSION.log(f"우선방위 축을 {tuple(b['md_hkl'])} 로 바꿨습니다.")
            if "tch" in b:
                st.models[i].profile.tch = bool(b["tch"])
                SESSION.log(f"프로파일 모드: "
                            f"{'TCH' if b['tch'] else '단순 pseudo-Voigt'}")
            if "bkg_order" in b:
                n = max(2, int(b["bkg_order"]))
                cur = st.bkg_coef
                st.bkg_coef = (cur + [0.0] * n)[:n]
                SESSION.log(f"배경 Chebyshev 차수를 {n} 항으로 바꿨습니다.")
            st._ycache = None
            SESSION.push_state()
            return {"ok": True}
        if path == "/api/run":
            plan = b["plan"]
            threading.Thread(target=SESSION.run_plan, args=(plan,),
                             daemon=True).start()
            return {"ok": True, "started": len(plan)}
        if path == "/api/rollback":
            return {"ok": SESSION.rollback(int(b["index"]))}
        if path == "/api/chat":
            return SESSION.ask(b["message"], b.get("backend"))
        if path == "/api/export":
            return {"path": export(b.get("dir", "."))}
        raise KeyError(f"알 수 없는 경로 {path}")

    # ---------------- helpers ----------------
    def _json(self, obj, code=200):
        # Python의 json은 Infinity/NaN을 그대로 내보내지만 JS의 JSON.parse는
        # 그것을 거부한다. 클라이언트가 조용히 죽지 않도록 여기서 막는다.
        self._send(code, json.dumps(_finite(obj), ensure_ascii=False,
                                    default=str).encode(), "application/json")

    def _send(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", f"{ctype}; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass


def export(outdir: str = ".") -> str:
    """정련 결과를 CIF + 패턴 + 요약 JSON 으로 내보낸다."""
    st = SESSION.state
    if st is None:
        raise RuntimeError("정련 상태가 없습니다.")
    os.makedirs(outdir, exist_ok=True)
    base = os.path.join(outdir, "refined")
    ph = st.models[0].phase
    with open(base + ".cif", "w") as f:
        f.write(f"data_{ph.name.replace(' ', '_')}\n")
        f.write(f"_symmetry_space_group_name_H-M  '{ph.spacegroup}'\n")
        for k, v in zip(["a", "b", "c"], ph.cell_params[:3]):
            f.write(f"_cell_length_{k}   {v:.6f}\n")
        for k, v in zip(["alpha", "beta", "gamma"], ph.cell_params[3:]):
            f.write(f"_cell_angle_{k}   {v:.4f}\n")
        f.write(f"_cell_volume   {ph.volume():.4f}\n")
        f.write("loop_\n _atom_site_label\n _atom_site_type_symbol\n"
                " _atom_site_fract_x\n _atom_site_fract_y\n"
                " _atom_site_fract_z\n _atom_site_occupancy\n"
                " _atom_site_B_iso_or_equiv\n")
        for s in ph.sites:
            f.write(f" {s.label} {s.type_symbol} {s.x:.5f} {s.y:.5f} "
                    f"{s.z:.5f} {s.occ:.4f} {s.biso:.4f}\n")
    yc = st.ycalc()
    np.savetxt(base + ".prf", np.c_[st.two_theta, st.yobs, yc,
                                    st.yobs - yc],
               header="2theta  Yobs  Ycalc  Ydiff", fmt="%.5f")
    with open(base + ".json", "w") as f:
        json.dump({"r_factors": st.r_factors(),
                   "phases": SESSION.status()["phases"],
                   "fractions": st.phase_fractions(),
                   "note_lebail": [m.phase.name for m in st.models
                                   if m.fmul is not None],
                   "params": SESSION.status()["params"],
                   "history": [{"label": h["label"], "r": h["r"]}
                               for h in SESSION.history],
                   "chat": SESSION.chat},
                  f, ensure_ascii=False, indent=2, default=str)
    SESSION.log(f"내보내기: {base}.cif / .prf / .json")
    return base


def main():
    ap = argparse.ArgumentParser("rietveld-auto")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--data", help="패턴 파일 (.xy/.dat/.xrdml)")
    ap.add_argument("--no-ka2", action="store_true", help="Kα1 단독")
    a = ap.parse_args()
    SESSION.set_beam("Cu", not a.no_ka2)
    if a.data:
        tt, y = read_xy(a.data)
        SESSION.load_pattern(tt, y, os.path.basename(a.data))
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), Handler)
    print(f"rietveld-auto  →  http://127.0.0.1:{a.port}")
    srv.serve_forever()


if __name__ == "__main__":
    main()
