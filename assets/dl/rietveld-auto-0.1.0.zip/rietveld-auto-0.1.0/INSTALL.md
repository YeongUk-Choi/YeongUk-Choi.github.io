# Rietveld Auto — getting it running

A Rietveld refinement engine for powder X-ray diffraction that is meant to be *driven*:
the engine itself is deterministic, and every command answers with one block of JSON, so
you — or an AI agent working for you — can read the diagnostics, decide the next step, and
reproduce the result later. Each step is snapshotted and can be rolled back.

## Install

Python 3.9 or newer.

```bash
pip install -r requirements.txt     # gemmi, numpy, scipy
```

Nothing is compiled and nothing is installed system-wide. A virtual environment is enough.

## Try it on the bundled pattern

`data/demo_VO2_M1.xy` is a synthetic VO₂ (M1) pattern generated from COD 3000344, so you can
check the whole path without your own data.

```bash
python -m rietveld.cli index   --data data/demo_VO2_M1.xy          # index without a CIF
python -m rietveld.cli search  --formula VO2                       # rank COD candidates
python -m rietveld.cli analyze --data data/demo_VO2_M1.xy --cod 3000344
python -m rietveld.cli serve   --data data/demo_VO2_M1.xy          # browser UI on 127.0.0.1:8765
```

`search` and `analyze --cod` fetch structures from the Crystallography Open Database, so those
two need an internet connection. `index` and a refinement from a local CIF work offline.

Patterns can be `.xy`, `.asc` or two-column text; see `rietveld/pattern.py` for what is parsed.

## What to expect — read this before trusting a number

**One shot is a starting point, not an answer.** Running `analyze` on the bundled pattern with
no guidance lands around Rwp 18, GOF 2.3. Guiding the same engine through a plan — choosing the
preferred-orientation axis, not refining zero and sample displacement together — reaches Rwp 8.1,
GOF 1.01 on that pattern, which is its noise limit. The gap is model selection, not optimisation.
That is the job the tool is shaped around: it reports what is wrong and what is correlated, and
expects a decision.

**Validation so far is on synthetic data.** Against the generated VO₂ M1 pattern it recovers the
lattice parameters to within 0.003 %, the March-Dollase parameter to 0.07 %, and ranks the correct
COD entry first. It has **not** yet been benchmarked against measured datasets previously refined
in FullProf or GSAS. Treat results on real data as something to check, not to cite.

**Physics guard rails.** Refinements that a crystal system does not allow are not offered at all;
others are classed HARD (rolled back immediately) or WARN (surfaced for a decision).

## Driving it from an AI agent

`SKILL.md` documents the command surface an agent should use. Every command returns JSON on
stdout and uses exit codes (0 ok, 1 user error, 2 network, 4 other), so two different agents can
reproduce and check each other's conclusions.

## Licence and contact

MIT — see `LICENSE`. If it helps your work I would like to hear about it, and if it breaks I
would rather know: YeongUk Choi, Department of Physics, Inha University — aowlr8945@gmail.com
